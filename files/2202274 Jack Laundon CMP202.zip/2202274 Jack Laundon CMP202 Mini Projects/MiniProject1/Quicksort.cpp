//includes header file
#include "Quicksort.h"
//library for timings
#include <chrono>
//library for vectors
#include <vector>
//library used to output to the console
#include <iostream>
//library for threads
#include <thread>
//library for futures
#include <future>
//library used in calculating the average of the timings for each sort
#include <numeric> 
//library for maps
#include<map>
//library for strings
#include <string>

int partition(std::vector<int>& vector, int begin, int end)
{
	//set the pivot to the beginning
	int pivot = vector[begin];

	//sets count to zero
	std::atomic<int> count = 0;

	//iterates over the vector
	for (int i = begin + 1; i <= end; i++)
	{
		if (vector[i] <= pivot)
		{
			count++;
		}
	}

	//calculates the position of the pivot
	int pivotPos = begin + count;
	//places the pivot
	std::swap(vector[pivotPos], vector[begin]);

	//variables for the nested loop
	int i = begin;
	int j = end;

	//ensures elements are in their correct positions (smaller than pivot on the left, bigger than pivot on the right)
	while (i < pivotPos && j > pivotPos)
	{
		while (vector[i] <= pivot && i <= pivotPos)
		{
			try {
				i++;
			}
			catch (const std::exception& e) {
				std::cerr << i << std::endl;
			}
		}
		while (vector[j] > pivot && j > pivotPos)
		{
			j--;
		}

		//if elements are in the wrong position
		if (i <= j)
		{
			//the elements are swapped
			std::swap(vector[i++], vector[j--]);
		}
	}
	//returns the pivot position
	return pivotPos;
}

//sort function
void sort(std::vector<int>& vector, int begin, int end)
{
	//if begin is less than end
	if (begin < end)
	{
		//gets the partition index from the partition function
		int partition_index = partition(vector, begin, end);
		//recursively calls itself
		//smaller element than pivot goes left
		sort(vector, begin, partition_index - 1);
		//higher element than pivcot goes right
		sort(vector, partition_index + 1, end);
	}
}

//function to fill the vector
void fill_vector(std::vector<int>& vector, size_t length)
{
	//fills the vector with a random number each time until the vector reaches the specified length
	for (int i = 0; i < length; i++)
	{
		vector.push_back(rand() % (length * 3));
	}
}

/* ----Quick Sort---- */

//sequential quicksort function
void sequential_quicksort(std::vector<int>& vector, int begin, int end)
{
	//sorts the vector
	sort(vector, begin, end);
}

/* ----Threads Quicksort---- */
//this method will be slower than the parallel quicksort as new threads are being created each time the function is called; the function is recursive so the thread overhead will be big
void threads_quicksort(std::vector<int>& vector, int begin, int end)
{
	//if begin is less than end
	if (begin < end)
	{
		//gets the partition index from the partition function
		int partitionindex = partition(vector, begin, end);
		//recursively calls the function
		//ref is used to pass by reference
		//two threads are created in each recursive call
		//smaller element than pivot goes left
		std::thread thread1(sort, std::ref(vector), begin, partitionindex - 1); 
		//bigger element than pivot goes right
		std::thread thread2(sort, std::ref(vector), partitionindex + 1, end); 
		//increments the thread count by two
		//joins the threads
		thread1.join();
		thread2.join();
	}
}


//parallel quicksort function
void parallel_quicksort(std::vector<int>& vector, int begin, int end, int partSize, int length)
{
	//vector of futures
	std::vector<std::future<void>> parts;
	//for loop essentially splits the vector into chunks and sorts each chunk asynchronously
	for (int i = 0; i < vector.size(); i += partSize)
	{
		//the result of this lambda function will be collected by the future
		parts.emplace_back(std::async(std::launch::async, [&vector, i, partSize, end]() {
			//sorts each chunk asynchronously
			sort(std::ref(vector), i, std::min(i + partSize - 1, end - 1));
			}));
	}

	//waits for all the asynchronous tasks to finish
	for (auto& part : parts)
	{
		part.get();
	}

	//puts the sorted chunks into a vector of vectors
	std::vector<std::vector<int>> vecOfVecs;

	for (int i = 0; i < vector.size(); i += partSize)
	{
		//uses std::min to avoid going out of bounds
		int end = std::min(length , i + partSize);

		//creates a "chunk" vector
		std::vector<int> chunk(vector.begin() + i, vector.begin() + end);

		//adds the chunk to the temporary vector
		vecOfVecs.push_back(chunk);
	}

	//clears the vector
	vector.clear();

	//merges the vector of vectors back into the original vector
	if (!vecOfVecs.empty())
	{
		//sets the original vector to the first sorted chunk in the vector of vectors
		vector = vecOfVecs[0];
		//for loop starts at 1 as 0 has already been assigned
		for (int i = 1; i < vecOfVecs.size(); i++)
		{
			//creates a temporary vector 
			std::vector<int> tempVec;
			//merges the original vector and the current element of the vector of vectors
			std::merge(vector.begin(), vector.end(), vecOfVecs[i].begin(), vecOfVecs[i].end(), std::back_inserter(tempVec));
			//adds the contents of the temporary vector to the original vector
			//the temporary vector will be destroyed when it goes out of scope, so there is no need to clear the temporary vector
			vector.swap(tempVec);
		}
	}
}




//function to calculate the average time taken for each sort
std::map<std::string, std::chrono::nanoseconds> calc_avg(std::vector<std::chrono::nanoseconds>& times)
{
	//creates a map to pair a string with a time in nanoseconds that will hold the mean and median average for each sort
	std::map<std::string, std::chrono::nanoseconds> avgTime;

	//uses std::accumulate to calculate the total of all the times in the vector
	std::chrono::nanoseconds total = std::accumulate(times.begin(), times.end(), std::chrono::nanoseconds(0));

	//calculates the mean
	std::chrono::nanoseconds meanAvg = total / times.size();
	//adds the mean to the map
	avgTime["Mean Average"] = meanAvg;

	//sorts the vector in order to find the median average
	sort(times.begin(), times.end());


	//calculates the median
	if (times.size() % 2 == 0)
	{
		//returns the average of the middle elements if the number of elements is even
		std::chrono::nanoseconds medianAvg = (times[(times.size() - 1) / 2] + times[(times.size() / 2)]) / 2;
		//adds the median to the map
		avgTime["Median Average"] = medianAvg;
	}
	else {
		//returns the mid point if the number of elements is odd
		std::chrono::nanoseconds medianAvg = times[times.size() / 2];
		//adds the median to the map
		avgTime["Median Average"] = medianAvg;
	}
	//returns the map
	return avgTime;
}

void print_avg(std::map<std::string, std::chrono::nanoseconds> avgs)
{
	//an iterator is used to print out the mean and median average from the map returned by the calc_avg() function

	std::map<std::string, std::chrono::nanoseconds>::iterator it = avgs.begin();

	//iterates over the map
	while (it != avgs.end())
	{
		//prints the results
		std::cout << it->first << ":" << std::endl;
		std::cout << it->second.count() << " nanoseconds." << std::endl;
		//increments the iterator by one
		it++;
	}
}

