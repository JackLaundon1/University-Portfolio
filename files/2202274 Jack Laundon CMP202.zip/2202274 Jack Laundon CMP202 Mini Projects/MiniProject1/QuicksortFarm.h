//ensures the header file is only included once
#pragma once
//library for vectors
#include <vector>

//struct for QuicksortTask
struct QuicksortTask {
	//QuicksortTask takes a vector and a length
	std::vector<int> vector;
	size_t length;
};