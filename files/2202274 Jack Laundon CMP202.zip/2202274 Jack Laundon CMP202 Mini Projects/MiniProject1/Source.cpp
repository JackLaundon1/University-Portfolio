//library to output to the console
#include <iostream>
//library for vectors
#include<vector>
//library for random
#include <stdlib.h> 
//library for time
#include <time.h>		
//library for timing
#include <chrono>		
//library for strings
#include <string>
//library for threads
#include <thread>
//library for futures
#include <future>
//includes a header file
#include "Quicksort.h"
//library for maps
#include <map>
//includes a header file
#include "Farm.h"
//includes a header file
#include "QuicksortFarm.h"
//library for parallel for
#include <ppl.h>

//vectors to be used to contain the timings for each sort
std::vector<std::chrono::nanoseconds> sequentialTimes;
std::vector<std::chrono::nanoseconds> parallelTimes;
std::vector<std::chrono::nanoseconds> threadTimes;
std::vector<std::chrono::nanoseconds> parallel_for_times;

/* ----Main Method---- */

int main()
{

	/* ----setup---- */
	//seeds the random function to ensure that the same data is generated each time
	srand(1);
	//initalises vector to be used for each sort
	std::vector<int> vector;

	//sets length of vector
	//the optimal length (for this system) is ten million (10,000,000) and the optimal number of parts to go with this is 100
	size_t length = 10000000;
	//this will stay as a constant
	size_t numParts = 100;
	//number of times the sort should run
	size_t numRuns = 10;

	//calculates the size of each part to be sorted in parallel 
	size_t partSize = length / numParts;

	/* ----Sequential Quicksort Using a Farm---- */

	//creates a farm object
	Farm farm;
	//runs the farm for the number of times specified
	for (int i = 0; i < numRuns; i++)
	{
		//fills the vector
		fill_vector(vector, length);
		//adds a task to the queue
		QuicksortTask mbt{ vector, length };
		farm.add_task(mbt);
		//clears the vector to avoid overflows
		vector.clear();
	}
	//runs the farm
	farm.run(numRuns);


	/* ----Quicksort with purely threads---- */
	//this is intentionally inefficient to demonstrate how purely creating threads is not a suitable solution due to the overheads created
	Concurrency::parallel_for(size_t(0), numRuns, [&](size_t i)
		{
			std::vector<int> parallelForVec;
			fill_vector(parallelForVec, length);
			//runs and times the sort
			auto start = std::chrono::high_resolution_clock::now();
			threads_quicksort(parallelForVec, 0, length - 1);
			auto end = std::chrono::high_resolution_clock::now();
			//calculates the time taken to run the sort
			std::chrono::nanoseconds timeTaken = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start);
			//the time taken is stored in a vector
			threadTimes.push_back(timeTaken);
			//clears the vector to avoid overflow
			vector.clear();
		});

	std::cout << "Quicksort just creating threads: Complete" << std::endl;

	/* ----Parallel Quicksort---- */

	//for loop used to run the parallel quicksort
	//the more it went on, the more threads were created and the overheads cancelled out the benefits of parallelism.  So, a sequential loop was used.
	for (int i = 0; i < numRuns; i++)
	{
		//fills the vector
		fill_vector(vector, length);
		//runs and times the sort
		auto start = std::chrono::high_resolution_clock::now();
		parallel_quicksort(vector, 0, length - 1, partSize, length);
		auto end = std::chrono::high_resolution_clock::now();
		//calculates the time taken by the sort
		std::chrono::nanoseconds timeTaken = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start);
		//stores the time taken in a vector
		parallelTimes.push_back(timeTaken);
		//clears the vector to avoid an overflow
		vector.clear();
	}
	std::cout << "Parallel Quicksort: Complete" << std::endl;
	//parallel quicksort using parallel for
	Concurrency::parallel_for(size_t(0), numRuns, [&](size_t i)
		{
			std::vector<int> parallelForVec;
			//fills the vector
			fill_vector(parallelForVec, length);
			//runs and times the sort
			auto start = std::chrono::high_resolution_clock::now();
			parallel_quicksort(parallelForVec, 0, length - 1, partSize, length);
			auto end = std::chrono::high_resolution_clock::now();
			//calculates the time taken by the sort
			std::chrono::nanoseconds timeTaken = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start);
			//stores the time taken in a vector
			parallel_for_times.push_back(timeTaken);
			//clears the vector to avoid an overflow
			parallelForVec.clear();
		});

	/* ----Calculates the average time taken by the sorts---- */

	//calculates avg for sequential
	std::map<std::string, std::chrono::nanoseconds> sequentialAvgs = calc_avg(sequentialTimes);
	//calculates avg for parallel
	std::map<std::string, std::chrono::nanoseconds> parallelAvgs = calc_avg(parallelTimes);
	//calculates avg for threads
	std::map<std::string, std::chrono::nanoseconds> threadAvgs = calc_avg(threadTimes);
	//calculates avg for parallel_for
	std::map<std::string, std::chrono::nanoseconds> parallelForAvgs = calc_avg(parallel_for_times);


	//clears the screen
	system("CLS");


	/* ----Prints out the results---- */

	std::cout << "Results:" << std::endl;

	std::cout << "" << std::endl;

	std::cout << "Each sort ran " << numRuns << " times" << std::endl;

	std::cout << "" << std::endl;
	//results for the sequential sort
	std::cout << "Results for the sequential sort:" << std::endl;

	//calls the print_avg function
	print_avg(sequentialAvgs);

	/* ----Separates the results--- */

	std::cout << "" << std::endl;

	for (int i = 0; i < 100; i++)
	{
		std::cout << "-";
	}

	std::cout << "" << std::endl;
	std::cout << "" << std::endl;

	//thread sort results
	std::cout << "Results for the thread sort: " << std::endl;

	//calls the print_avg function
	print_avg(threadAvgs);

	std::cout << "" << std::endl;

	/* ----Separates the results---- */

	for (int i = 0; i < 100; i++)
	{
		std::cout << "-";
	}

	std::cout << "" << std::endl;
	std::cout << "" << std::endl;

	//results for the parallel sort
	std::cout << "Results for the parallel sort:" << std::endl;

	//calls the print_avg function
	print_avg(parallelAvgs);


	//separates the results
	for (int i = 0; i < 100; i++)
	{
		std::cout << "-";
	}

	std::cout << "" << std::endl;
	std::cout << "" << std::endl;

	std::cout << "Results for the parallel_for parallel sort:" << std::endl;
	
	//calls the print_avg function
	print_avg(parallelForAvgs);

	for (int i = 0; i < 100; i++)
	{
		std::cout << "-";
	}

	std::cout << "" << std::endl;
	std::cout << "" << std::endl;


	//calculates and outputs speedups

	//sequential to parallel speedups
	auto meanSpeedup = static_cast<double>(sequentialAvgs["Mean Average"].count() / parallelAvgs["Mean Average"].count());
	auto medianSpeedup = static_cast<double>(sequentialAvgs["Median Average"].count() / parallelAvgs["Median Average"].count());

	//purely threads to parallel speedups
	auto threadMeanSpeedup = static_cast<double>(threadAvgs["Mean Average"].count() / parallelAvgs["Mean Average"].count());
	auto threadMedianSpeedup = static_cast<double>(threadAvgs["Median Average"].count() / parallelAvgs["Median Average"].count());


	//parallel_for to sequential for speedups
	auto parallelForMeanSpeedup = static_cast<double>(parallelForAvgs["Mean Average"].count() / parallelAvgs["Mean Average"].count());
	auto parallelForMedianSpeedup = static_cast<double>(parallelForAvgs["Median Average"].count() / parallelAvgs["Median Average"].count());

	//outputs speedups
	std::cout << "Speedups for parallel to sequential: " << std::endl;
	std::cout << "Mean speedup: " << meanSpeedup << " times faster." << std::endl;
	std::cout << "Median speedup: " << medianSpeedup << " times faster." << std::endl;

	std::cout << "" << std::endl;

	std::cout << "Speedups for parallel to just threads: " << std::endl;
	std::cout << "Mean speedup: " << threadMeanSpeedup << " times faster" << std::endl;
	std::cout << "Median speedup: " << threadMedianSpeedup << " times faster" << std::endl;

	std::cout << "" << std::endl;
	std::cout << "Speedups for parallel quicksort using a normal for loop to using a parallel_for:" << std::endl;
	std::cout << "Mean speedup: " << parallelForMeanSpeedup << " times faster" << std::endl;
	std::cout << "Median speedup: " << parallelForMedianSpeedup << " times faster" << std::endl;

	//prints spaces
	std::cout << "" << std::endl;

	for (int i = 0; i < 4; i++)
	{
		std::cout << "" << std::endl;
	}

	//pauses so that the final output does not disappear immediately
	system("pause");

	return 0;
}