//ensures the header file will only be included once
#pragma once
//library for vectors
#include <vector>
//library for atomic variables
#include <atomic>
//library for timings
#include <chrono>
//library for futures
#include <future>
//library for maps
#include <map>

//declares the variables to be used
//extern is used to avoid unresolved external errors
extern std::vector<std::chrono::nanoseconds> sequentialTimes;
extern std::vector<std::chrono::nanoseconds> parallelTimes;
extern std::vector<std::chrono::nanoseconds> threadTimes;
extern std::vector<std::chrono::nanoseconds> parallel_for_times;

//partition function definition
int partition(std::vector<int>& vector, int begin, int end);
//sort function definition
void sort(std::vector<int>& vector, int begin, int end);
//fill vector function definition.  The length can be changed in the main method
void fill_vector(std::vector<int>& vector, size_t length);

/* ----Quick Sort---- */

//sequential quicksort function definition
void sequential_quicksort(std::vector<int>& vector, int begin, int end);

//quicksort with just threads function definition
void threads_quicksort(std::vector<int>& vector, int begin, int end);

//parallel quicksort function definition
void parallel_quicksort(std::vector<int>& vector, int begin, int end, int partSize, int length);

//calc_avg function definition
std::map<std::string, std::chrono::nanoseconds> calc_avg(std::vector<std::chrono::nanoseconds>& times);

//print_avg function definition
void print_avg(std::map<std::string, std::chrono::nanoseconds>);
