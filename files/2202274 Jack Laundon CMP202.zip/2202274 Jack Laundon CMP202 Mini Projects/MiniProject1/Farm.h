//ensures that the header file is only included once
#pragma once
//library for queues
#include <queue>
//library for vectors
#include <vector>
//library for mutex
#include <mutex>
//library for threads
#include <thread>
//includes a header file
#include "QuicksortFarm.h"
//library for atomic variables
#include <atomic>

//class for the farm
class Farm
{
public:
	//add_task function definition
	void add_task(const QuicksortTask& task);
	//run function definition
	void run(size_t numRuns);
	//progress definition
	void progress(size_t numRuns);
private:
	//taskQueue definition
	std::queue<QuicksortTask> taskQueue;
	//mutex definitions
	std::mutex queueMutex;
	std::mutex vecMutex;
	std::mutex progressMutex;
	//condition variable definition
	std::condition_variable cv;
	//completed tasks definition
	int completedTasks;
	//completed definition
	std::atomic<bool> complete;
};

