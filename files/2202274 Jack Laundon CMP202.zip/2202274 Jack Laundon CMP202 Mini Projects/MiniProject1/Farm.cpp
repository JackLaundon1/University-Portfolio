//includes header file
#include "Farm.h"
//includes header file
#include "Quicksort.h"
//includes header file
#include "QuicksortFarm.h"
//library for future
#include <future>
//library for timings
#include <chrono>
//library for output
#include <iostream>

//function to add a task to the queue
void Farm::add_task(const QuicksortTask& task)
{
	//locks the mutex
	std::lock_guard<std::mutex> lock(queueMutex);
	//adds the task to the queue
	taskQueue.push(task);
}

//runs the tasks
void Farm::run(size_t numRuns)
{
	std::cout << "Sequential Sort: 0/" << numRuns << " tasks completed." << std::endl;
	complete = false;
	//sets completed tasks to zero
	completedTasks = 0;
	//calculates number of threads
	int numThreads = std::thread::hardware_concurrency();
	//vector of threads
	std::vector<std::thread> threads(numThreads);

	//creates a progress thread for the progress function
	std::thread progressThread(&Farm::progress, this, numRuns);
	//lambda expression
	auto executeTask = [&]()
		{
			//permanent loop
			while (true)
			{
				//creates an object of QuicksortTask
				QuicksortTask task;
				{
					//locks the mutex
					std::lock_guard <std::mutex> lock(queueMutex);
					//checks for tasks
					if (taskQueue.empty())
					{
						break;
					}
					//gets the next task
					task = taskQueue.front();
					//removes the task from the queue
					taskQueue.pop();
				}
				//runs and times the sequential quicksort
				auto start = std::chrono::high_resolution_clock::now();
				sequential_quicksort(task.vector, 0, task.length - 1);
				auto end = std::chrono::high_resolution_clock::now();
				//locks the mutex
				std::lock_guard<std::mutex> lock(progressMutex);
				//increments completed tasks by one
				completedTasks++;
				//notifies the condition variable
				cv.notify_one();
				//calculates the time taken
				auto timeTaken = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start);
				//locks the mutex to ensure only one thread is accessing the vector at once
				std::lock_guard<std::mutex> vecLock(vecMutex);
				//stores the time taken in a vector
				sequentialTimes.push_back(timeTaken);
			}
		};
	//launches threads to execute the tasks
	for (int i = 0; i < numThreads; i++)
	{
		//launches a thread
		threads[i] = std::thread(executeTask);
	}
	//waits for all threads to complete their task
	for (auto& thread : threads)
	{
		//joins the threads
		thread.join();
	}
	{
		//locks the mutex
		std::lock_guard<std::mutex> lock(progressMutex);
		//sets complete to true
		complete = true;
		//notifies the condition variable
		cv.notify_one();
	}
	//joins the thread
	progressThread.join();
}

void Farm::progress(size_t numRuns)
{
	//lock the mutex
	std::unique_lock<std::mutex> lock(progressMutex);
	//sets tasks to zero
	int tasks = 0;
	//while loop that executes until all tasks are completed
	while (!complete.load() || tasks < completedTasks)
	{
		//lambda expression for the condition variable
		cv.wait(lock, [this, &tasks]
			{
				return tasks < completedTasks || complete;
			});
		//while not all tasks are complete
		while (tasks < completedTasks)
		{
			//clears the screen
			system("CLS");
			//increments the task counter
			tasks++;
			//outputs the status
			std::cout << "Sequential Sort: completed " << tasks << "/" << numRuns << " tasks." << std::endl;
		}
	}
}

