//includes required libraries 
#include <CL/sycl.hpp>    
#include <iostream>   
#include <algorithm>    
#include <chrono>    
#include <cstdlib>   
#include <ctime>    

//sets namespace to sycl
using namespace sycl;

//sets dimensions for the matrices 
//row dimension for matrix A 
constexpr size_t M = 6000;
//shared dimension - column dimension for matrix A and row dimension for matrix B 
constexpr size_t N = 7000;
//column dimension for matrix B 
constexpr size_t P = 8000;

//matrix A will be MxN, matrix B will be NxP, and matrix C (the result of A*B) will be MxP 

//sets tile sizes for the tile matrix multiplications - this is done using the maximum work group size  
//these must be adjusted to suit matrix dimensions  
constexpr size_t TILE_SIZE_M = 16;
constexpr size_t TILE_SIZE_N = 16;

//function to display the matrices 
void display_matrices(const float* A, const float* B, float* C)
{
    //outputs a partial view of matrix A   
    std::cout << "Partial view of matrix A:" << std::endl;

    //sets number of rows to show    
    int numRowsToShow = std::min(10, static_cast<int>(M));

    //sets number of columns to show    
    int numColsToShow = std::min(10, static_cast<int>(N));

    //displays matrix A up to the specified rows and columns limit 

    for (int i = 0; i < numRowsToShow; ++i) {
        for (int j = 0; j < numColsToShow; ++j) {
            std::cout << A[i * N + j] << "\t";
        }
        std::cout << std::endl;
    }

    //outputs a partial view of matrix B    
    std::cout << "Partial view of matrix B:" << std::endl;

    //sets number of rows to show 
    numRowsToShow = std::min(10, static_cast<int>(N));

    //sets number of columns to show 
    numColsToShow = std::min(10, static_cast<int>(P));

    //displays matrix B up to the specified rows and columns limit 
    for (int i = 0; i < numRowsToShow; ++i) {
        for (int j = 0; j < numColsToShow; ++j) {
            std::cout << B[i * P + j] << "\t";
        }
        std::cout << std::endl;
    }

    //outputs a partial view of matrix C (result)    
    std::cout << "Partial view of result matrix (A x B):" << std::endl;

    //sets number of rows to show 
    numRowsToShow = std::min(10, static_cast<int>(M));

    //sets number of columns to show 
    numColsToShow = std::min(10, static_cast<int>(P));

    //displays matrix C up to the specified rows and columns limit 
    for (int i = 0; i < numRowsToShow; ++i) {
        for (int j = 0; j < numColsToShow; ++j) {
            std::cout << C[i * P + j] << "\t";
        }
        std::cout << std::endl;
    }
}

//function for tiled matrix multiplication 
void tiled_matrix_multiplication(const float* A, const float* B, float* C, queue& q)
{
    //defines buffers 
    buffer<float, 2> bufA(A, range<2>(M, N));
    buffer<float, 2> bufB(B, range<2>(N, P));
    buffer<float, 2> bufC(C, range<2>(M, P));

    //submits to the queue 
    q.submit([&](handler& h) {
        //sets up accessors 
        auto accA = bufA.get_access<access::mode::read>(h);
        auto accB = bufB.get_access<access::mode::read>(h);
        auto accC = bufC.get_access<access::mode::write>(h);

        //allocates local memory for the tiles 
        accessor<float, 2, access::mode::read_write, access::target::local> tileA(range<2>(TILE_SIZE_M, TILE_SIZE_N), h);
        accessor<float, 2, access::mode::read_write, access::target::local> tileB(range<2>(TILE_SIZE_N, TILE_SIZE_M), h);

        //parallel for loop  
        h.parallel_for<class TiledMatrixMulKernel>(nd_range<2>(range<2>(M, P), range<2>(TILE_SIZE_M, TILE_SIZE_N)), [=](nd_item<2> item) {
            //sets variables using the local and global ID of the nd_item 
            const int globalRow = item.get_global_id(0);
            const int globalCol = item.get_global_id(1);
            const int localRow = item.get_local_id(0);
            const int localCol = item.get_local_id(1);

            //sets the temporary variable to zero, with "f" stating that it should be a float 
            float temp = 0.0f;

            //loops over the tiles 
            for (int t = 0; t < N; t += TILE_SIZE_N) {
                //loads tiles into local memory    
                //if statements used to avoid out of bounds errors 
                if ((globalRow < M) && (t + localCol < N))
                {
                    //sets the tileA variable 
                    tileA[localRow][localCol] = accA[globalRow][t + localCol];
                }
                else {
                    //sets tileA to empty 
                    tileA[localRow][localCol] = 0.0f;
                }

                if (t + localRow < N && globalCol < P)
                {
                    //sets tileB variable 
                    tileB[localRow][localCol] = accB[t + localRow][globalCol];
                }
                else {
                    //sets tileB to empty 
                    tileB[localRow][localCol] = 0.0f;
                }

                //waits for work items to finish  
                item.barrier(access::fence_space::local_space);

                //performs multiplication 
                for (int k = 0; k < TILE_SIZE_N; ++k) {
                    //updates the temporary variable to the result 
                    temp += tileA[localRow][k] * tileB[k][localCol];
                }

                //waits for all work-items to finish   
                item.barrier(access::fence_space::local_space);
            }
            //stores the result in buffer C
            accC[globalRow][globalCol] = temp;
            });
        });
}



//function for matrix multiplication using buffers and accesors 
void matrix_multiplication(const float* A, const float* B, float* C, queue& q)
{
    //sets buffers 
    buffer<float, 2> bufA(A, range<2>(M, N));
    buffer<float, 2> bufB(B, range<2>(N, P));
    buffer<float, 2> bufC(C, range<2>(M, P));

    //submits to the queue 
    q.submit([&](handler& h) {
        //sets up accessors 
        auto accA = bufA.get_access<access::mode::read>(h);
        auto accB = bufB.get_access<access::mode::read>(h);
        auto accC = bufC.get_access<access::mode::write>(h);

        //parallel for loop 
        h.parallel_for<class MatrixMulKernel>(range<2>(M, P), [=](id<2> idx) {

            //sets variables to be used in a loop 
            const int i = idx[0];
            const int j = idx[1];
            //sets temporary variable to zero, with "f" stating it should be a float 
            float temp = 0.0f;

            //loops over the matrix and performs multiplication 
            for (int k = 0; k < N; ++k) {
                //updates the temp variable with the result 
                temp += accA[i][k] * accB[k][j];
            }
            //stores the result in buffer C 
            accC[i][j] = temp;
            });
        });
}

//function for matrix multiplication using implicit usm memory 
void i_usm_matrix_multiplication(const float* A, const float* B, float* C, queue& q)
{
    //sets the queue 
    q.submit([&](handler& h) {
        //parallel for loop 
        h.parallel_for<class MatrixMulKernelUSMi>(range<2>(M, P), [=](id<2> idx) {
            //sets variables to be used in a loop 
            const int i = idx[0];
            const int j = idx[1];
            //sets the temporary variable to zero, with "f" stating that it should be a float 
            float temp = 0.0f;

            //loops over the matrix and performs multiplication 
            for (int k = 0; k < N; k++) {
                //updates the temp variable with the result 
                temp += A[i * N + k] * B[k * P + j];
            }

            //stores the result in matrix C 
            C[i * P + j] = temp;
            });
        });
    //waits for all tasks to complete 
    q.wait();
}



//function to perform matrix multiplication using explicit esm 
void e_usm_matrix_multiplication(const float* A_host, const float* B_host, float* C_host, queue& q) {
    //allocates memory for the matrices on the device 
    float* A = malloc_device<float>(M * N, q);
    float* B = malloc_device<float>(N * P, q);
    float* C = malloc_device<float>(M * P, q);

    //copies data from host to device    
    q.memcpy(A, A_host, sizeof(float) * M * N);
    q.memcpy(B, B_host, sizeof(float) * N * P);

    //waits for all tasks to complete    
    q.wait();

    //submits to the queue 
    q.submit([&](handler& h) {

        //parallel for loop 
        h.parallel_for<class MatrixMulKernelUSMe>(range<2>(M, P), [=](id<2> idx) {

            //sets up variables to be used in a loop 
            const int i = idx[0];
            const int j = idx[1];
            //sets the temporary variable to zero, with "f" stating it should be a float 
            float temp = 0.0f;

            //loops over the matrix and performs multiplication 
            for (int k = 0; k < N; ++k) {
                //updates the temp variable with the result 
                temp += A[i * N + k] * B[k * P + j];
            }

            //stores the result in matrix C 
            C[i * P + j] = temp;
            });
        });

    //copies the result back to host memory    
    q.memcpy(C_host, C, sizeof(float) * M * P).wait();

    //frees device memory    
    free(A, q);
    free(B, q);
    free(C, q);
}



//function for matrix multiplication using subgroups 
//this function follows the tiled approach as it is the fastest but is modified to use subgroup operations 
void subgroup_matrix_multiplication(const float* A, const float* B, float* C, queue& q)
{

    //sets up buffers 
    buffer<float, 2> bufA(A, range<2>(M, N));
    buffer<float, 2> bufB(B, range<2>(N, P));
    buffer<float, 2> bufC(C, range<2>(M, P));

    //submits to the queue 
    q.submit([&](handler& h) {
        //sets up accessors 
        auto accA = bufA.get_access<access::mode::read>(h);
        auto accB = bufB.get_access<access::mode::read>(h);
        auto accC = bufC.get_access<access::mode::write>(h);

        //allocates local memory for the tiles 
        accessor<float, 2, access::mode::read_write, access::target::local> tileA(range<2>(TILE_SIZE_M, TILE_SIZE_N), h);
        accessor<float, 2, access::mode::read_write, access::target::local> tileB(range<2>(TILE_SIZE_N, TILE_SIZE_M), h);

        //parallel for loop 
        h.parallel_for<class SubgroupMatrixMulKernel>(nd_range<2>(range<2>(M, P), range<2>(TILE_SIZE_M, TILE_SIZE_N)), [=](nd_item<2> item)
            {
                //sets up subgroup 
                auto sg = item.get_sub_group();

                //sets up variables using global and local ID of the nd_item 
                const int globalRow = item.get_global_id(0);
                const int globalCol = item.get_global_id(1);
                const int localRow = item.get_local_id(0);
                const int localCol = item.get_local_id(1);

                //sets temporary variable to zero, with "f" stating that it should be a float 
                float temp = 0.0f;

                //loops over the tiles 
                for (int i = 0; i < N; i += TILE_SIZE_N)
                {
                    //loads tile A into local memory  - tile B is not loaded as the group_broadcast function is being used to broadcast to accB
                    //if statements used to avoid out of bounds errors 
                    if ((globalRow < M) && (i + localCol < N))
                    {
                        //sets the tileA variable 
                        tileA[localRow][localCol] = accA[globalRow][i + localCol];
                    }

                    //sets tileA to empty 
                    else {
                        tileA[localRow][localCol] = 0.0f;
                    }

                    //uses subgroup barrier to wait for all tasks to finish 
                    sg.barrier();

                    //performs the matrix multiplication  
                    for (int k = 0; k < TILE_SIZE_N; ++k) {
                        //broadcasts to all other threads to distribute tileA between threads  
                        auto broadcastVar = group_broadcast(sg, tileA[localRow][k]);
                        //updates temp with the result 
                        temp += broadcastVar * accB[i + k][globalCol];
                    }

                    //uses subgroup barrier to wait for all tasks to be complete 
                    sg.barrier();
                }

                //stores the result in global memory 
                accC[globalRow][globalCol] = temp;
            });
        });
}

int main() {

    //sets up gpu selector
    gpu_selector selector;
    queue q(selector);

    //sets up cpu selector
    cpu_selector cpuSel;

    queue c(cpuSel);



    /* Cpu */

    //sets up matrices
    //"new" is used to avoid a stack overflow
    float* cA = new float[M * N];
    float* cB = new float[N * P];
    float* cC = new float[M * P];

    //fills matrix A
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            cA[i * N + j] = i;
        }
    }


    //fills matrix B
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            cB[i * P + j] = j;
        }
    }



    //queryies local memory size and maximum work-group size    
    auto localMemSize = q.get_device().get_info<info::device::local_mem_size>();
    auto maxWorkGroupSize = q.get_device().get_info<info::device::max_work_group_size>();

    //outputs local memory size and max work group size
    std::cout << "Local Memory Size: " << localMemSize << " bytes\n";
    std::cout << "Max Work-Group Size: " << maxWorkGroupSize << std::endl;


    //times and runs the function with a cpu selector
    auto cstart = std::chrono::high_resolution_clock::now();
    matrix_multiplication(cA, cB, cC, c);
    c.wait();
    auto cstop = std::chrono::high_resolution_clock::now();
    auto cduration = std::chrono::duration_cast<std::chrono::nanoseconds>(cstop - cstart);



    //displays the matrices
    display_matrices(cA, cB, cC);

    //frees the memory    
    delete[] cA;
    delete[] cB;
    delete[] cC;

    //displays the results
    std::cout << "" << std::endl;
    std::cout << "CPU Matrix Multiplication:" << std::endl;
    std::cout << "For the Data: " << M << "x" << N << " and " << N << "x" << P << " matrices, multiplication took " << cduration.count() << " nanoseconds.\n";
    std::cout << "" << std::endl;

    /* Matrix Multiplication*/

    //defines the matrices
    float* A = new float[M * N];
    float* B = new float[N * P];
    float* C = new float[M * P];

    //fills matrix A
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            A[i * N + j] = i;
        }
    }


    //fills matrix B
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            B[i * P + j] = j;
        }
    }

    //times and runs the function
    auto start = std::chrono::high_resolution_clock::now();
    matrix_multiplication(A, B, C, q);
    q.wait();
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(stop - start);



    //displays the matrices
    display_matrices(A, B, C);

    //frees the memory    
    delete[] A;
    delete[] B;
    delete[] C;

    //displays the results
    std::cout << "" << std::endl;
    std::cout << "Matrix Multiplication:" << std::endl;
    std::cout << "For the Data: " << M << "x" << N << " and " << N << "x" << P << " matrices, multiplication took " << duration.count() << " nanoseconds.\n";
    std::cout << "" << std::endl;



    /* i_usm_multiplication */

    //defines the matrices
    float* A_i = malloc_shared<float>(M * N, q);
    float* B_i = malloc_shared<float>(N * P, q);
    float* C_i = malloc_shared<float>(M * P, q);

    //fills Matrix A     
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            A_i[i * N + j] = i;
        }
    }



    //fills Matrix B    
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            B_i[i * P + j] = j;
        }
    }

    //times and runs the function
    auto i_start = std::chrono::high_resolution_clock::now();
    i_usm_matrix_multiplication(A_i, B_i, C_i, q);
    q.wait();
    auto i_end = std::chrono::high_resolution_clock::now();
    auto i_duration = std::chrono::duration_cast<std::chrono::nanoseconds>(i_end - i_start);

    //displays the matrices
    display_matrices(A_i, B_i, C_i);

    //frees the memory
    free(A_i, q);
    free(B_i, q);
    free(C_i, q);

    //displays the results
    std::cout << "" << std::endl;
    std::cout << "i_usm_matrix_multiplication" << std::endl;
    std::cout << "For the Data: " << M << "x" << N << " and " << N << "x" << P << " matrices, multiplication took " << i_duration.count() << " nanoseconds.\n";
    std::cout << "" << std::endl;

    /* e_usm */
    //defines the matrices
    float* A_e = new float[M * N];
    float* B_e = new float[N * P];
    float* C_e = new float[M * P];

    //fills Matrix A     
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            A_e[i * N + j] = i;
        }
    }

    //fills Matrix B    
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            B_e[i * P + j] = j;
        }
    }

    //times and runs the function
    auto e_start = std::chrono::high_resolution_clock::now();
    e_usm_matrix_multiplication(A_e, B_e, C_e, q);
    q.wait();
    auto e_end = std::chrono::high_resolution_clock::now();
    auto e_duration = std::chrono::duration_cast<std::chrono::nanoseconds>(e_end - e_start);

    //displays the matrices
    display_matrices(A_e, B_e, C_e);

    //displays the results
    std::cout << "" << std::endl;
    std::cout << "e_usm_matrix_multiplication" << std::endl;
    std::cout << "For the Data: " << M << "x" << N << " and " << N << "x" << P << " matrices, multiplication took " << e_duration.count() << " nanoseconds.\n";
    std::cout << "" << std::endl;


    //frees the memory
    delete[] A_e;
    delete[] B_e;
    delete[] C_e;

    /* Tiled*/

    //defines the matrices
    float* tA = new float[M * N];
    float* tB = new float[N * P];
    float* tC = new float[M * P];

    //fills matrix A
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            tA[i * N + j] = i;
        }
    }

    //fills matrix B
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            tB[i * P + j] = j;
        }
    }

    //times and runs the function
    auto t_start = std::chrono::high_resolution_clock::now();
    tiled_matrix_multiplication(tA, tB, tC, q);
    q.wait();
    auto t_stop = std::chrono::high_resolution_clock::now();
    auto t_duration = std::chrono::duration_cast<std::chrono::nanoseconds>(t_stop - t_start);

    //displays the matrices
    display_matrices(tA, tB, tC);



    //frees the memory    
    delete[] tA;
    delete[] tB;
    delete[] tC;

    //displays the results
    std::cout << "" << std::endl;
    std::cout << "Tiled Matrix Multiplication:" << std::endl;
    std::cout << "For the Data: " << M << "x" << N << " and " << N << "x" << P << " matrices, multiplication took " << t_duration.count() << " nanoseconds.\n";
    std::cout << "" << std::endl;

    /* Subgroup */

    //defines the matrices
    float* sA = new float[M * N];
    float* sB = new float[N * P];
    float* sC = new float[M * P];

    //fills matrix A
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            sA[i * N + j] = i;
        }
    }

    //fills matrix B
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < P; j++) {
            sB[i * P + j] = j;
        }
    }

    //times and runs the function
    auto s_start = std::chrono::high_resolution_clock::now();
    subgroup_matrix_multiplication(sA, sB, sC, q);
    q.wait();
    auto s_stop = std::chrono::high_resolution_clock::now();
    auto s_duration = std::chrono::duration_cast<std::chrono::nanoseconds>(s_stop - s_start);

    //displays the matrices 
    display_matrices(sA, sB, sC);

    //frees the memory    
    delete[] sA;
    delete[] sB;
    delete[] sC;

    //displays the results
    std::cout << "" << std::endl;
    std::cout << "Subgroup Matrix Multiplication:" << std::endl;
    std::cout << "For the Data: " << M << "x" << N << " and " << N << "x" << P << " matrices, multiplication took " << s_duration.count() << " nanoseconds.\n";
    std::cout << "" << std::endl;

    //uses pause so that the results do not immediately disappear 
    system("PAUSE");
    return 0;
}