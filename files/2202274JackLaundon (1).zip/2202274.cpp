//includes the iostream library to allow input and output
#include <iostream>
//includes the library to allow use of strings
#include <string>
//includes the library that allows the use of the sleep function
#include <Windows.h>
//includes the library that allows the use of the exit function
#include <stdlib.h>
//includes the library that allows writing to files
#include <fstream>
//includes the library that allows deleting files
#include <stdio.h>
//states that we are using the standard namespace
using namespace std;

//variable that stores the pet's name is a global variable so that any function can access it
string name;
//function prototype for the feed function
int feed(int*);
//function prototype for the nap function
int nap(int*);
//function prototype for the function to display the current state
void currentState(int*, int*, int*);
//function prototype for the play menu function
void playMenu();
//function prototype for the save function
void save(int*, int*, int*);
//function prototype for the function that displays messages and puts the pet to sleep when the pet is overfed
int overfed(int*);
//function prototype for the menu function
void menu(int*, int*, int*);
//variable that holds the name of the file
string fileName;

int main()
{
	//variables that hold the pet's various statistics
	int foodLevel;
	int tiredLevel;
	int happyLevel;
	//asks the user if they want to load from a previous save
	char saveDecision;
	cout << "Do you want to load a previous save? Y/N?" << endl;
	cin >> saveDecision;
	//declares the variable fileExist to false
	bool fileExist = false;
	//if statement that executes if the user enters Y or y
	if (saveDecision == 'Y' || saveDecision == 'y')
	{
		//variables used for reading from files
		string line;
		fstream myFile;
		bool file1 = false;
		bool file2 = false;
		bool file3 = false;

		//checks if saveFile1 exists
		myFile.open("saveFile1.txt");
		//if statement executes if saveFile1 exists
		if (myFile)
		{
			//sets fileExist and file1 to true
			fileExist = true;
			file1 = true;
		}
		//closes the file
		myFile.close();

		//checks if saveFile2 exists
		myFile.open("saveFile2.txt");
		//if statement executes if saveFile2 exists
		if (myFile)
		{
			//sets fileExist and file2 to true
			fileExist = true;
			file2 = true;
		}
		//closes the file
		myFile.close();

		//checks is saveFile3 exists
		myFile.open("saveFile3.txt");
		//if statement executes if saveFile3 exists
		if (myFile)
		{
			//sets fileExist and file3 to true
			fileExist = true;
			file3 = true;
		}
		//closes the file
		myFile.close();

		//if statement executes if no save files exist
		if (fileExist == false)
		{
			//outputs the message to the user
			cout << "No save files exist - starting a new game." << endl;
			cout << "Game starting..." << endl;
			//pauses for 5 seconds
			Sleep(5000);
		}

		//executes if at least one save file exists
		else {
			//asks the user which save file they would like to choose
			cout << "Which save do you want to play?" << endl;
			int saveFile;
			//if statement executes if saveFile1 exists
			if (file1 == true)
			{
				//opens saveFile1 and reads in from the file
				myFile.open("saveFile1.txt", ios::in);
				if (myFile.is_open())
				{
					while (getline(myFile, line))
					{
						//do nothing
					}
					//gets the name of the pet from the file using substrings
					name = line.substr(3);
					//outputs the name of the pet for that file
					cout << name << " (1)" << endl;
					//closes the file
					myFile.close();
				}
				else {
					//outputs error message
					cout << "Error opening file." << endl;
				}
			}

			//if statement executes if saveFile2 exists
			if (file2 == true)
			{
				//opens saveFile2 and reads from the file
				myFile.open("saveFile2.txt", ios::in);
				if (myFile.is_open())
				{
					while (getline(myFile, line))
					{
						//do nothing
					}
					//gets the name of the pet from the file using substrings
					name = line.substr(3);
					//outputs the name of the pet for that file
					cout << name << " (2)" << endl;
					//closes the file
					myFile.close();
				}
				else {
					//outputs error message
					cout << "Error opening file." << endl;
				}
			}

			//if statement executes if saveFile3 exists
			if (file3 == true)
			{
				//opens saveFile3 and reads from the file
				myFile.open("saveFile3.txt", ios::in);
				if (myFile.is_open())
				{
					while (getline(myFile, line))
					{
						//do nothing

					}
					//gets the name of the pet from the file using substrings
					name = line.substr(3);
					//outputs the name of the pet for that file
					cout << name << " (3)" << endl;
					//closes the file
					myFile.close();
				}
				else {
					//outputs error message
					cout << "Error opening file." << endl;
				}
			}

			//reads in which save file the user wants to use
			cin >> saveFile;
			//input validation
			while (saveFile != 1 && saveFile != 2 && saveFile != 3)
			{
				cout << "Invalid response - try again" << endl;
				cin >> saveFile;
			}

			//switch statement 
			switch (saveFile)
			{
				//if the user enters 1, fileName is set to saveFile1.txt
			case 1:
				fileName = "saveFile1.txt";
				break;
				//if the user enters 2, fileName is set to saveFile2.txt
			case 2:
				fileName = "saveFile2.txt";
				break;
				//if the user enters 3, fileName is set to saveFile3.txt
			case 3:
				fileName = "saveFile3.txt";
				break;
			}
			//opens and reads from the selected file
			myFile.open(fileName, ios::in);
			if (myFile.is_open())
			{
				while (getline(myFile, line))
				{
					//do nothing

				}
				//assigns the relevent variables from the file using substrings
				foodLevel = stoi(line.substr(0, 1));
				tiredLevel = stoi(line.substr(1, 1));
				happyLevel = stoi(line.substr(2, 1));
				name = line.substr(3);
				//closes the file
				myFile.close();
			}
			else {
				//outputs error message
				cout << "Error opening file." << endl;
			}
		}
	}
	//if statement executes if the user enters N or n
	if (saveDecision == 'N' || saveDecision == 'n' || fileExist == false)
	{
		//assigns the pet's levels to the default of 4
		foodLevel = 4;
		tiredLevel = 4;
		happyLevel = 4;
		//outputs a loading message
		cout << "Cyberpet loading..." << endl;
		//prompts the user to enter their pet's name
		cout << "Enter your pet's name:" << endl;
		//takes in the pet's name from the user
		cin >> name;
		//makes the first letter of the pet's name a capital letter
		name[0] = toupper(name[0]);
	}
	//clears the screen
	system("cls");
	//calls the menu function and passes in the foodLevel, tiredLevel, and happyLevel, using pointers
	menu(&foodLevel, &tiredLevel, &happyLevel);
	return 0;
}

//menu function
void menu(int* fl, int* tl, int*hl)
{
	//variable that stores the pet's hunger level
	int hunger = *fl;
	//variable that stores the pet's energy level
	int energy = *tl;
	//variable that stores the pet's happiness level, calculated by the average of the hunger and energy levels
	int happiness = *hl;
	//variables that stores the happiness increase, if there is one
	int happinessIncrease = 0;
	//declares the variable that holds the decision entered by the user in the menu 
	char decision;
	//do while loop that will be constantly running the menu until the user enters "q", and then the loop will break as the condition for the loop to continue is no longer met
	do
	{
		//the happiness value is calculated every time the user returns to the menu so that the happiness updates based on the values of the hunger, energy, and happiness increase if there is one
		happiness = ((hunger + energy) / 2) + happinessIncrease;
		if (happinessIncrease >= 1)
		{
			//decreases the value of the happiness increase by one every time the user returns to the menu
			happinessIncrease--;
		}
		//this runs every time the user returns to the menu, so that the pet's energy will always update to the correct value
		if (energy <= 1)
		{
			energy = 4;
		}
		//displays the options on the menu screen
		cout << "Menu:" << endl;
		cout << "Press F to feed " << name << endl;
		cout << "Press N to give " << name << " a nap" << endl;
		cout << "Press P to play with " << name << endl;
		cout << "Press D to display " << name << "'s current state" << endl;
		cout << "Press Q to quit" << endl;
		//reads in the decision from the user
		cin >> decision;
		system("cls");
		//series of if statements to determine what to do next, as switch statements do not work with chars in c++
		if (decision == 'F' || decision == 'f')
		{
			//if the user enters "f", the feed function will be called, the hunger value will be passed in using a pointer, and the hunger value will be assigned to the output of the function
			hunger = feed(&hunger);
		}
		else if (decision == 'N' || decision == 'n')
		{
			//if the user enters "n", the nap function will be called, the energy value will be passed in using a pointer, and the energy value will be assigned to the output of the function
			energy = nap(&energy);
		}
		else if (decision == 'P' || decision == 'p')
		{
			char playChoice;
			//if statement that executes if the pet's hunger is 2
			if (hunger == 2)
			{
				//outputs a warning message
				cout << name << " is starving and may be too hungry to play.  Play anyway? Y/N?" << endl;
				//reads in the user's decision
				cin >> playChoice;
				//input validation
				while (playChoice != 'Y' && playChoice != 'y' && playChoice != 'N' && playChoice != 'n')
				{
					cout << "Invalid response - try again" << endl;
					cin >> playChoice;
				}
				//if statement that executes if the user enters N or n
				if (playChoice == 'N' || playChoice == 'n')
				{
					//do nothing
				}
				//if statement that executes if the user enters Y or y
				else if (playChoice == 'Y' || playChoice == 'y')
				{
					//calls the playMenu function and displays the options to play with the pet
					playMenu();
					int playDecision;
					//reads in the user's choice of how to play with the pet
					cin >> playDecision;
					//input validation 
					while (playDecision != 1 && playDecision != 2 && playDecision != 3)
					{
						cout << "Invalid response - try again" << endl;
						cin >> playDecision;
					}
					//clears the screen
					system("cls");
					//switch statement
					switch (playDecision)
					{
						//if the user enters 1, the hunger and energy decrease by 1 and the happiness increases by 1
					case 1:
						hunger--;
						energy--;
						happinessIncrease++;
						//outputs confirmation message to the user
						cout << "You played ball with " << name << endl;
						break;
						//if the user enters 2, the hunger and energy decrease by 2 and the happiness increases by 2
					case 2:
						hunger-=2;
						energy-=2;
						happinessIncrease+=2;
						//outputs confirmation message
						cout << "You played frisbee with " << name << endl;
						break;
					}
					//calls the function to display the pet's current state, passing in hunger, energy, and happiness using pointers
					currentState(&hunger, &energy, &happiness);
				}
			}
			//if statement that executes if the pet's energy is 2
			else if (energy == 2)
			{
				//outputs warning message to the user
				cout << name << " is falling asleep and may be too tired to play.  Play anyway? Y/N?" << endl;
				//reads in the user's decision
				cin >> playChoice;
				//input validation
				while (playChoice != 'Y' && playChoice != 'y' && playChoice != 'N' && playChoice != 'n')
				{
					cout << "Invalid response - try again" << endl;
					cin >> playChoice;
				}
				//if statement that executes if the user enters N or n
				if (playChoice == 'N' || playChoice == 'n')
				{
					//do nothing
				}
				//if statement that executes if the user enters Y or y
				else if (playChoice == 'Y' || playChoice == 'y')
				{
					//calls the playMenu function to display the options to play with the pet
					playMenu();
					int playDecision;
					//reads in the user's decision on how to play with their pet
					cin >> playDecision;
					//input validation
					while (playDecision != 1 && playDecision != 2 && playDecision != 3)
					{
						cout << "Invalid response - try again" << endl;
						cin >> playDecision;
					}
					//switch statement
					switch (playDecision)
					{
						//if the user enters 1, the hunger and energy decrease by 1 and the happiness increases by 1
					case 1:
						hunger--;
						energy--;
						happiness++;
						//outputs confirmation message
						cout << "You played ball with " << name << endl;
						break;
					case 2:
						//if the user enters 2, the hunger and energy decrease by 2 and the happiness increases by 2
						hunger-=2;
						energy-=2;
						happiness+=2;
						//outputs confirmation message
						cout << "You played frisbee with " << name << endl;
						break;
					}
					//calls the function do display the pet's current state, passing in hunger, energy, and happiness using pointers
					currentState(&hunger, &energy, &happiness);
				}
			}
			else {
			//calls the playMenu function to display the options to play with the pet
				playMenu();
				int playDecision;
				//reads in the user's decision on how to play with their pet
				cin >> playDecision;
				//input validation
				while (playDecision != 1 && playDecision != 2 && playDecision != 3)
				{
					cout << "Invalid response - try again" << endl;
					cin >> playDecision;
				}
				//switch statement
				switch (playDecision)
				{
					//if the user enters 1, the hunger and energy decrease by 1 and the happiness increases by 1
				case 1:
					hunger--;
					energy--;
					happinessIncrease = 1;
					//calculates the happiness based on the average of the hunger and energy + the happiness increase
					happiness = ((hunger + energy) / 2) + happinessIncrease;
					//if statements that executes if happiness is greater than 5
					if (happiness > 5)
					{
						//sets happiness to 5
						happiness = 5;
					}
					//outputs confirmation message
					cout << "You played ball with " << name << endl;
					break;
					//if the user enters 2,
				case 2:
					//if statement that executes if the hunger is less than or equal to 3
					if (hunger <= 3)
					{
						//outputs warning message
						cout << name << " is starving and may be too hungry to play.  Play anyway? Y/N?" << endl;
						//reads in the user's decision
						cin >> playChoice;
						//input validation
						while (playChoice != 'Y' && playChoice != 'y' && playChoice != 'N' && playChoice != 'n')
						{
							cout << "Invalid response - try again" << endl;
							cin >> playChoice;
						}
						//if statement executes if the user enters N or n
						if (playChoice == 'N' || playChoice == 'n')
						{
							//do nothing
						}
						//if statement executes if the user enters Y or y
						else if (playChoice == 'Y' || playChoice == 'y')
						{
							//outputs confirmation message
							cout << "You played frisbee with " << name << endl;
							//decreases hunger and energy by 2
							hunger -= 2;
							energy -= 2;
						}
					}
					//if statement executes if the energy is less than or equal to 3
					else if (energy <= 3)
					{
						//outputs warning message
						cout << name << " is falling asleep and may be too tired to play.  Play anyway? Y/N?" << endl;
						//reads in the user's decision
						cin >> playChoice;
						//input validation
						while (playChoice != 'Y' && playChoice != 'y' && playChoice != 'N' && playChoice != 'n')
						{
							cout << "Invalid response - try again" << endl;
							cin >> playChoice;
						}
						//if statement executes if the user enters N or n
						if (playChoice == 'N' || playChoice == 'n')
						{
							//do nothing
						}
						//if statement executes if the user enters Y or y
						else if (playChoice == 'Y' || playChoice == 'y')
						{
							//outputs confirmation message
							cout << "You played frisbee with " << name << endl;
							//decreases hunger and energy by 2
							hunger -= 2;
							energy -= 2;
						}
					}
					else {
						//decreases the hunger and energy by 2 and sets the happiness increase to 2
						hunger -= 2;
						energy -= 2;
						happinessIncrease = 2;
						//calculates happiness using the average of hunger and energy plus the happiness increase
						happiness = ((hunger + energy) / 2) + happinessIncrease;
						//if statement executes if happiness is greater than 5
						if (happiness > 5)
						{
							//sets happiness to 5
							happiness = 5;
						}
						//outputs confirmation message
						cout << "You played frisbee with " << name << endl;
						//pauses for 3 seconds
						Sleep(3000);
						break;
					}
				}
				//calls the function to view the current state, passing in hunger, energy, and happiness using pointers
				currentState(&hunger, &energy, &happiness);
			}
			//clears the screen
			system("cls");
		}
		else if (decision == 'D' || decision == 'd')
		{
			//if the user enters "d", the function to view the current state will be called, the hunger and energy values will be passed in using pointers, and will display the hunger and energy levels of the pet.
			currentState(&hunger, &energy, &happiness);
		}
		//the loop will run until the user enters "q" to quit, then the loop will break
	} while (decision != 'q' && decision != 'Q');
	//clears the screen
	system("cls");
	//calls the save function, passing in hunger, energy, and happiness using pointers
	save(&hunger, &energy, &happiness);
}

//feed function
int feed(int* h)
{
	//assigns the value of the memory address of "hunger" to the variable "hungry" using pointers
	int hungry = *h;
	//outputs options to the user
	cout << "Would you like to feed " << name << ":" << endl;
	cout << "Or a small biscuit(1)?" << endl;
	cout << "A light snack (2)?" << endl;
	cout << "A full meal (3)?" << endl;
	//integer variable to hold the choice that the user enters
	int choice;
	cin >> choice;
	system("cls");
	//input validation
	while (choice != 1 && choice != 2 && choice != 3)
	{
		cout << "Invalid response - try again" << endl;
		cin >> choice;
	}
	//switch statement to determine what happens next based on the current hunger level of the pet
	switch (choice)
	{
	case 1:
		//if the user enters 1 and the hunger level = 5, the pet will get overfed and go to sleep
		if (hungry > 4)
		{
			//calls the function that displays messages and puts the pet to sleep when the pet is overfed, passes in the hungry variable using pointers, and sets the hunger value to the output of the function
			hungry = overfed(&hungry);
		}
		//if the user enters 1 and the hunger level is not greater than 4, the hunger level is increased by one
		else
		{
			hungry += 1;
		}
		break;
	case 2:
		//if the user enters 2 and if the hunger level is over 3, the pet will get overfed and go to sleep
		if (hungry > 3)
		{
			//calls the function that displays messages and puts the pet to sleep when the pet is overfed, passes in the hungry variable using pointers, and sets the hunger value to the output of the function
			hungry = overfed(&hungry);
		}
		//if the user enters 2 and the hunger level is not over 3, the hunger level is increased by two
		else 
		{
			hungry += 2;
		}
		break;
	case 3:
		//if the user enters 3 and if the hunger level is over 2, the pet will get overfed and go to sleep
		if (hungry > 2)
		{
			//calls the function that displays messages and puts the pet to sleep when the pet is overfed, passes in the hungry variable using pointers, and sets the hunger value to the output of the function
			hungry = overfed(&hungry);
		}
		//if the user enters 3 and the hunger level is not over 2, the hunger level is increased by three
		else
		{
			hungry += 3;
		}
		break;
	}
	//clears the screen
	system("cls");
	//returns the hungry value
	return hungry;
}

//function to give the pet a nap
int nap(int* e)
{
	//assigns the value of the memory address of "energy" to the variable "energyLevel"
	int energyLevel = *e;
	//integer variable to hold the decision that the user enters
	int decision;
	//outputs options to the user
	cout << "Would you like to make " << name << ":" << endl;
	cout << "Go for a short snooze (1)?" << endl;
	cout << "Take a relaxing nap(2)?" << endl;
	cout << "Or go for a deep sleep (3)?" << endl;
	cin >> decision;
	//input validation
	while (decision != 1 && decision != 2 && decision != 3)
	{		
		cout << "Invalid response - try again" << endl;
		cin >> decision;
	}
	//switch statement that determines what to do next based on the user's input
	switch (decision)
	{
		case 1:
			//if the user enters 1, the pet will sleep for 15 seconds and the energy level will increase by one
			if (energyLevel == 5)
			{
				cout << name << " is already wide awake" << endl;
			}
			else {
				//outputs a message that states the pet is going to sleep 
				cout << name << " will now go for a short snooze for 15 seconds." << endl;
				//calls the sleep program and pauses the program for 15 seconds
				Sleep(7000);
				//outputs the pet's 'dialogue'
				cout << name << ": zzzzz" << endl;
				//calls the sleep program and pauses the program for the remainder of the 15 seconds
				Sleep(8000);
				//increases the engergy level by one
				energyLevel += 1;
			}
			break;
		case 2:
			//if the user enters 2, the pet will sleep for one minute and the energy level will increase by three
			if (energyLevel == 5)
			{
				cout << name << " is already wide awake" << endl;
			}
			else {
				cout << name << " will now go for a relaxing nap for one minute." << endl;
				//for loop to display the pet's 'dialogue' every 15 seconds while it's asleep
				for (int i = 0; i < 4; i++)
				{
					//for loop to display the pet's 'dialogue' every 15 seconds while it's asleep
					Sleep(15000);
					//outputs the pet's 'dialogue'
					cout << name << ": zzzzz" << endl;
				}
				if (energyLevel > 2)
				{
					energyLevel = 5;
				}
				else {
					//increases the pet's energy level by 3
					energyLevel += 3;
				}
			}
			break;
		case 3:
			//if the user enters 3, the pet will sleep for a minute and a half/90 seconds and the energy level is set to 5 (which is full)
			if (energyLevel == 5)
			{
				cout << name << " is already wide awake" << endl;
			}
			else {
				cout << name << " will now go for a deep sleep for a minute and a half." << endl;
				for (int i = 0; i < 6; i++)
				{
					//for loop to display the pet's 'dialogue' every 15 seconds while it's asleep
					Sleep(15000);
					//outputs the pet's 'dialogue'
					cout << name << ": zzzzz" << endl;
				}
				//sets the pet's energy level to max
				energyLevel = 5;
			}
			break;
	}
	system("cls");
	//returns the energyLevel
	return energyLevel;
}

//function to display the pet's current state
void currentState(int* hungerState, int* energyState, int* happinessState)
{
	//assigns the value of the memory address of "hunger" to the variable "hungerDisplay"
	int hungerDisplay = *hungerState;
	//assigns the vale of the memory address of "energy" to the variable "energyDisplay"
	int energyDisplay = *energyState;
	//assigns the value of the memory address of "happiness" to the variable "happinessDisplay"
	int happinessDisplay = *happinessState;
	//if the pet is dangerously low on food or sleep, the happiness state will turn to extremely unhappy
	if (hungerDisplay == 2 || energyDisplay == 2)
	{
		happinessDisplay = 1;
	}
	
	//switch statement that determines what to display based on the hunger level
	switch (hungerDisplay)
	{
	case 0:
		//if the hunger value is less than one, the pet will die from hunger and the save file will be deleted
		cout << name << " is dead - game over" << endl;
		cout << "Closing..." << endl;
		if (fileName == "saveFile1.txt")
		{
			//deletes saveFile1
			remove("saveFile1.txt");
		}
		else if (fileName == "saveFile2.txt")
		{
			//deletes saveFile2
			remove("saveFile2.txt");
		}
		else if (fileName == "saveFile3.txt")
		{
			//deletes saveFile3
			remove("saveFile3.txt");
		}
		cout << "Save file deleted." << endl;
		//exits the program
		exit(0);
		break;
	case 1:
		//if the hunger value is one, the pet will die from hunger and the save file will be deleted
		cout << name << " is dead - game over" << endl;
		cout << "Closing..." << endl;
		if (fileName == "saveFile1.txt")
		{
			//deletes saveFile1
			remove("saveFile1.txt");
		}
		else if (fileName == "saveFile2.txt")
		{
			//deletes saveFile2
			remove("saveFile2.txt");
		}
		else if (fileName == "saveFile3.txt")
		{
			//deletes saveFile3
			remove("saveFile3.txt");
		}
		cout << "Save file deleted." << endl;
		//exits the program
		exit(0);
		break;
	case 2:
		//if the hunger value is two, a message will be output telling the user that the pet is starving and will die if not fed
		cout << name << " is starving and will die soon if not fed." << endl;
		break;
	case 3:
		//if the hunger value is two, a message will be output telling the user that the pet is rather hungry
		cout << name << " is rather hungry." << endl;
		break;
	case 4:
		//if the hunger value is two, a message will be output telling the user that the pet is slightly peckish
		cout << name << " is slightly peckish." << endl;
		break;
	case 5:
		//if the hunger value is two, a message will be output telling the user that the pet is well fed
		cout << name << " is well fed." << endl;
		break;
	}
	//switch statement that determines what to display based on the energy level
	switch (energyDisplay)
	{
	case 0:
		//if the energy level is less than one, the pet will collapse from lack of sleep and go into a 5 minute coma
		cout << name << " has collapsed due to lack of sleep, and will go into a coma for five minutes" << endl;
		Sleep(300000);
		cout << name << " has woken up" << endl;
		break;
	case 1:
		//if the energy level is one, the pet will collapse from lack of sleep and go into a 5 minute coma
		cout << name << " has collapsed due to lack of sleep, and will go into a coma for five minutes" << endl;
		Sleep(300000);
		cout << name << " has woken up" << endl;
		break;
	case 2:
		//if the energy level is two, a message will be output telling the user that the pet will collapse soon if it does not go to sleep soon
		cout << name << " is falling alseep and will collapse soon if not given a nap." << endl;
		break;
	case 3:
		//if the energy level is three, a message will be output telling the user that the pet is tired
		cout << name << " is tired." << endl;
		break;
	case 4:
		//if the energy level is four, a message will be output telling the user that the pet is awake
		cout << name << " is awake." << endl;
		break;
	case 5:
		//if the energy level is five or above, a message will be output telling the user that the pet is wide awake
		cout << name << " is wide awake." << endl;
		break;
	}
	//switch statement
	switch (happinessDisplay)
	{
	case 1:
		//if happiness = 1
		cout << name << " is extremely unhappy" << endl;
		break;
	case 2:
		//if happiness = 2
		cout << name << " is unhappy" << endl;
		break;
	case 3:
		//if happiness = 3
		cout << name << " is miffed" << endl;
		break;
	case 4:
		//if happiness = 4
		cout << name << " is happy" << endl;
		break;
	case 5:
		//if happiness = 5
		cout << name << " is absolutely hunky dory" << endl;
		break;
	}
	//pauses for 5 seconds
	Sleep(5000);
	//clears the screen
	system("cls");
}
//save function
void save(int* hs, int* es, int* has)
{
	//variables to use for saving the game
	int hungerSave = *hs;
	int energySave = *es;
	int happinessSave = *has;
	fstream file;
	string line;
	string saveFile;
	string saveName;
	//asks the user to choose a file to save to
	cout << "Choose a file to save to" << endl;
	//opens saveFile1.txt and reads from the file
	file.open("saveFile1.txt", ios::in);
	//if the file exists
	if (file.is_open())
	{
		while (getline(file, line))
		{
			//do nothing
		}
		//gets the name of the pet from the file using substrings
		saveName = line.substr(3);
		//outputs the name of the pet
		cout << saveName << " (1)" << endl;
		//closes the file
		file.close();
	}
	else {
		//outputs empty
		cout << "Empty (1)" << endl;
	}
	//opens saveFile2.txt and reads from the file
	file.open("saveFile2.txt", ios::in);
	//if the file exists
	if (file.is_open())
	{
		while (getline(file, line))
		{
			//do nothing
		}
		//gets the name of the pet from the file using substrings
		saveName = line.substr(3);
		//outputs the name of the pet
		cout << saveName << " (2)" << endl;
		//closes the file
		file.close();
	}
	else {
		//outputs empty
		cout << "Empty (2)" << endl;
	}
	//opens saveFile3.txt and reads from the file
	file.open("saveFile3.txt", ios::in);
	//if the file exists
	if (file.is_open())
	{
		while (getline(file, line))
		{
			//do nothing
		}
		//gets the name of the pet from the file using substrings
		saveName = line.substr(3);
		//outputs the name of the pet
		cout << saveName << " (3)" << endl;
		//closes the file
		file.close();
	}
	else {
		//outputs empty
		cout << "Empty (3)" << endl;
	}
	int saveFileDecision;
	//reads in the user's decision for which save file to use
	cin >> saveFileDecision;
	//input validation
	while (saveFileDecision != 1 && saveFileDecision != 2 && saveFileDecision != 3)
	{
		cout << "Invalid response - try again" << endl;
		cin >> saveFileDecision;
	}
	//switch statement
	switch (saveFileDecision)
	{
		//if the user enters 1, the game is save to saveFile1.txt
	case 1:
		saveFile = "saveFile1.txt";
		break;
		//if the user enters 2, the game is save to saveFile2.txt
	case 2:
		saveFile = "saveFile2.txt";
		break;
		//if the user enters 3, the game is save to saveFile3.txt
	case 3:
		saveFile = "saveFile3.txt";
		break;
	}
	//opens the specified file and writes to it
	file.open(saveFile, ios::out);
	//if the file can't be found
	if (!file)
	{
		//outputs error message
		cout << "Error saving to file" << endl;
	}
	else {
		//writes to the specified file
		file << hungerSave << energySave << happinessSave << name;
		//outputs confirmation message
		cout << "File saved successfully!" << endl;
		//closes the file
		file.close();
	}
}


int overfed(int* h)
{
	//assigns the value of the memory address of hungry to the variable "hungerLevel" using pointers
	int hungerLevel = *h;
	//outputs the message
	cout << name << " has been overfed and has decided to go to sleep for one minute" << endl;
	//for loop to display the pet's 'dialogue' every 15 seconds while it's asleep
	for (int i = 0; i < 4; i++)
	{
		//calls the sleep function and pauses the program for 15 seconds
		Sleep(15000);
		//outputs the pet's 'dialogue'
		cout << name << ": zzzzz" << endl;
	}
	//outputs a message after the pet has 'woken up' telling the user that their pet is now well fed
	cout << name << " is now well fed" << endl;
	//pauses for 5 seconds
	Sleep(5000);
	//clears the screen
	system("cls");
	//sets the hunger level to 5
	hungerLevel = 5;
	//returns hungerLevel
	return hungerLevel;
}

//play menu function
void playMenu()
{
	//outputs the options to play with the pet
	cout << "Would you like to:" << endl;
	cout << "Play ball with " << name << "(1)? Energy and hunger cost: 1. Happiness increase: +1" << endl;
	cout << "Play frisbee with " << name << "(2)? Energy and hunger cost: 2. Happiness increase: +2" << endl;
}

