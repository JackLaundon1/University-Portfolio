<?php 
  ob_start();
  session_start();
?>

<!doctype html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CMP204 Unit Two Coursework Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/script.js"></script>
    <!-- jQuery library -->
	<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <?php include_once "includes/links.php" ?>
    </header>

    <h2 class = "text-center">Sign Up</h2>
    <?php 
    //if session errorMessage is set
        if(isset($_SESSION["errorMessage"]))
        {
          //displays error message
          echo "<h3 class = 'text-danger text-center'>Error: {$_SESSION['errorMessage']}</h3>";
          unset($_SESSION["errorMessage"]);
        }
      ?>
        <br>
    <div class = "container text-center">
      <div class = "row">
        <div class = "col-sm mx-auto text-white">
          <!-- form -->
          <form action="processRegistration.php" class = "form" method = "post">
            Username: <input type= "text" name = "username" required> <br>
            Password: <input type= "password" name = "password" minlength = "8" required> <br>
            Confirm Password: <input type = "password" name = "confirmPassword" minlength = "8" required> <br>
            <input type="checkbox" id = "checkBox" name = "termsConditions" required>
            <label for="checkBox">By signing up, you agree to our<a href="gdpr.php">Terms and Conditions</a></label>
            <br>
            <div class = "text-center text-white">
              <button type = "submit" class = "btn btn-dark">Submit</button>
              <hr>
            </div>
            <br>
          </form>
        </div>
      </div>
      <div class = "row">
        <div class = "col-sm">
          <h3 class = "text-white">Already Have An Account?</h3>
        </div>
      </div>
      <div class = "row">
        <div class = "col-sm">
          <h3><a href="login.php">Sign In</a></h3>
        </div>
      </div>
    </div>
    <hr>
    <?php include_once "includes/footer.php" ?>
    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>


</body>

</html>