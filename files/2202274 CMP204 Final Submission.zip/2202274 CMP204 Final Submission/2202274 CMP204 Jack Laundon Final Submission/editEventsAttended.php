<html><body>
<?php
//includes database connection information
include_once("includes/connectionString.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    //starts the session
    ob_start();
    session_start();
    //sets variables
    $eventName = validate($_POST["eventName"]);
    $eventDate = validate($_POST["eventDate"]);
    $eventLocation = validate($_POST["eventLocation"]);
    $eventName = mysqli_real_escape_string($conn, $eventName);
    $eventDate = mysqli_real_escape_string($conn, $eventDate);
    $eventLocation = mysqli_real_escape_string($conn, $eventLocation);
    $newEventName = validate($_POST["newEventName"]);
    $newEventDate = validate($_POST["newEventDate"]);
    $newEventLocation = validate($_POST["newEventLocation"]);
    $newEventName = mysqli_real_escape_string($conn, $newEventName);
    $newEventDate = mysqli_real_escape_string($conn, $newEventDate);
    $newEventLocation = mysqli_real_escape_string($conn, $newEventLocation);
    $sessionUsername = $_SESSION["username"];

    //checks if the event already exists in the database using a prepared statement
    $sql = mysqli_prepare($conn, "SELECT eventname FROM events WHERE eventname = ? AND eventDate = ? AND eventLocation = ? AND username = ?");
    //binds parameters
    mysqli_stmt_bind_param($sql, 'ssss', $eventName, $eventDate, $eventLocation, $sessionUsername);
    //executes the prepared statement
    mysqli_stmt_execute($sql);
    //binds the result
    mysqli_stmt_store_result($sql);
    //if the event exists
    if(mysqli_stmt_num_rows($sql) > 0)
    {
        //checks if the proposed event exists
        $sql = mysqli_prepare($conn, "SELECT  eventname, eventDate, eventLocation WHERE eventname = ? AND eventDate = ? AND eventLocation  = ? AND username = ?");
        //sets parameters
        mysqli_stmt_bind_param($sql, 'ssss', $newEventName, $newEventDate, $newEventLocation, $sessionUsername);
        //executes the statement
        mysqli_stmt_execute($sql);
        //stores the result
        mysqli_stmt_store_result($sql);
        //if the proposed event does not exist
        if(mysqli_stmt_num_rows($sql) == 0)
        {
            //starts to create the prepared statement
            $sql = mysqli_prepare($conn, "UPDATE events SET eventname = ?, eventDate = ?, eventLocation = ? WHERE eventname = ? AND eventDate = ? AND eventLocation = ? AND username = ?");
            //binds parameters
            mysqli_stmt_bind_param($sql, 'sssssss', $newEventName, $newEventDate, $newEventLocation, $eventName, $eventDate, $eventLocation, $sessionUsername);
            //executes the prepared statement
            mysqli_stmt_execute($sql);
            //sets the session message
            $_SESSION["message"] = "Event Updated Successfully";
            //redirects to user profile
            header("location: userProfile.php");
        }
        else{
            //sets error message
            $_SESSION["errorMessage"] = "The Proposed Event Already Exists";
            //redirects to user profile
            header("location: userProfile.php");
        }
    }
    //username exists
    else{
        //display username is taken message - ajax?
        $_SESSION["errorMessage"] = "Event Not Found";
        //redirects to user profile
        header("location: userProfile.php");
    }        
}


//input validation
function validate($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
 ?>
</body></html>