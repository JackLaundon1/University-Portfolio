<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class = "col-sm text-center text-white">
                <?php
                //sets variables
                $name = "";
                $wins = "";
                $losses = "";
                $draws = "";
                //includes database connection information
                include_once("includes/connectionString.php");
                //uses a prepared statement to get the player stats from the database
                $sql = mysqli_prepare($conn, "SELECT playerName, wins, losses, draws FROM stats");
                //executes the statement
                mysqli_stmt_execute($sql);
                //binds the results to variables
                mysqli_stmt_bind_result($sql, $name, $wins, $losses, $draws);
                //displays information from the table from the database
                echo"<table><tr><th>Player</th><th>Wins</th><th>Losses</th><th>Draws</th></tr>";
                while(mysqli_stmt_fetch($sql)){
                    echo "<tr>";
                    echo "<td>" . $name . "</td>";
                    echo "<td>" . $wins . "</td>";
                    echo "<td>" . $losses . "</td>";
                    echo "<td>" . $draws . "</td>";
                }
                echo "</table>";
                //closes the statement and connection
                mysqli_stmt_close($sql);
                mysqli_close($conn);
                ?>            
            </div>
        </div>
    </div>

</body>

</html>