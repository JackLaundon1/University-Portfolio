<?php
//starts the session to access session variables
session_start();
?>

<!-- unsets session variables -->
<?php
session_unset();
?>

<!-- ends the session -- >
<?php
session_destroy();
//redirects to index.php
header("location: index.php")
?>
