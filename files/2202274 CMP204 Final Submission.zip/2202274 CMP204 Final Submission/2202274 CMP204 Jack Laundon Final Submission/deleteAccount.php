<html><body>
<?php
//starts the session
session_start();
ob_start();
//includes database connection details
include_once("includes/connectionString.php");
//sets the session username
$sessionUsername = $_SESSION["username"];

//prepared statement to delete an account
$sql = mysqli_prepare($conn, "DELETE FROM userDetails WHERE username = ?");
//binds parameters
mysqli_stmt_bind_param($sql, 's', $sessionUsername);
//executes the prepared statement
mysqli_execute($sql);


//prepared statement to delete all events associated with account
$sql = mysqli_prepare($conn, "DELETE FROM events WHERE username = ?");
mysqli_stmt_bind_param($sql, 's', $sessionUsername);
mysqli_execute($sql);
//unsets session variables
session_unset();

//closes the statement and connection
mysqli_stmt_close($sqlt);
mysqli_close($conn);

//ends the session
session_destroy();
//redirects to user index.php
header("location: index.php")
?>
</body></html>