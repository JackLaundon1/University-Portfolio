<!doctype html>

<html lang="en">

<head>
  <!--sets up the web page-->
  <meta charset="utf-8">
  <title>COOL ESPORTS TEAM</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  <link rel="stylesheet" href="css/style.css">
  <script src="javascript/script.js"></script>
  <!-- jQuery library -->
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"
    integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
</head>

<body>
  <header>
    <!-- includes the navbar -->
    <?php include_once "includes/links.php" ?>
  </header>
  <div id="privacySeal">
    <!-- image from: https://cdn5.vectorstock.com/i/1000x1000/14/99/gdpr-compliance-seal-template-vector-20871499.jpg -->
    <img src="images\privacy seal.png" alt="privacy seal" height=100px width=100px>
  </div>
  <h1 class="text-white text-center">eSports Team Privacy Policy</h1>

  <table class="text-white">
    <thead>
      <tr>
        <th class="reqCol">GDPR Policy</th>
      </tr>
    </thead>

    <tbody>
      <tr>
        <td>If you sign up, your personal information may be securely stored. This will include your username and
          password.</td>
      </tr>

      <tr>
        <td>We would like to use your information in order to provide services tailored to you.</td>
      </tr>
      <tr>
        <td>Your data will be used in order to offer functionalities, such as displaying events attended.</td>
      </tr>
      <tr>
        <td>Your data will be stored for a maximum of one year. If you do not use this website for more than this
          period, your data will be destroyed.</td>
      </tr>
      <tr>
        <td>Your data will be stored securely and safely. If your data is mishandled, we will be fined by the GDPR
          Information Commissioner. If you have any questions about this policy, email gpdrcollection@email.domain</td>
      </tr>
    </tbody>



  </table>
  <?php include_once "includes/footer.php" ?>
  <!-- Latest compiled Bootstrap JavaScript -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
    crossorigin="anonymous"></script>
</body>

</html>