<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Upcoming Events</title>
    <meta name = "viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <script src="javascript/script.js"></script>
    <!-- jQuery library -->
	<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <?php include_once "includes/links.php" ?>
    </header>
    <h1 class="text-center text-white" id="eventsHeader">Upcoming Events</h1>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://www.esportinsure.com/media/1141/event-liability-pod-copy.jpg?anchor=center&mode=crop&width=400&height=400&rnd=131949724200000000_ -->
                    <img class="card-img-top" src="images\stadium1.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://i.pinimg.com/474x/b6/11/a0/b611a0c6d2ef558f3a2758e6357ac2fd.jpg_ -->
                    <img class="card-img-top" src="images\stadium2.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://cdnb.artstation.com/p/assets/images/images/058/987/431/smaller_square/heckler-carballo-gatell-render-nestle-nestech-2016-v3-1.jpg?1675370419_ -->
                    <img class="card-img-top" src="images\stadium3.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://animationxpress.com/wp-content/uploads/2020/04/Esports_Seating-Reconfiguration_2400-1600x1067.jpg_ -->
                    <img class="card-img-top" src="images\stadium4.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
        </div>
         <div class="row">
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://www.esportinsure.com/media/1141/event-liability-pod-copy.jpg?anchor=center&mode=crop&width=400&height=400&rnd=131949724200000000_ -->
                    <img class="card-img-top" src="images\stadium1.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://i.pinimg.com/474x/b6/11/a0/b611a0c6d2ef558f3a2758e6357ac2fd.jpg_ -->
                    <img class="card-img-top" src="images\stadium2.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://cdnb.artstation.com/p/assets/images/images/058/987/431/smaller_square/heckler-carballo-gatell-render-nestle-nestech-2016-v3-1.jpg?1675370419_ -->
                    <img class="card-img-top" src="images\stadium3.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="card text-center mx-auto mb-3" id="event-card">
                    <!--image from https://animationxpress.com/wp-content/uploads/2020/04/Esports_Seating-Reconfiguration_2400-1600x1067.jpg_ -->
                    <img class="card-img-top" src="images\stadium4.jpg">
                    <div class="card-body">
                        <h5 class="card-title">Team 1 Vs Team 2 <br>Stadium Name<br>XX:XX GMT<br>DD/MM/YYYY</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once "includes/footer.php" ?>

    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>