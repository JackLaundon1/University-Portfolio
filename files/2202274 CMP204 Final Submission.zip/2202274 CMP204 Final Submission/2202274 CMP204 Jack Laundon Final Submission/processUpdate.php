<html><body>
<?php
//starts session
ob_start();
session_start();
include_once("includes/connectionString.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    //sets variables
    $newUsername = validate($_POST["username"]);
    $newPassword = validate($_POST["password"]);
    $newUsername = mysqli_real_escape_string($conn, $newUsername);
    $newPassword = mysqli_real_escape_string($conn, $newPassword);
    $hash = password_hash($newPassword, PASSWORD_DEFAULT);

    //sets sessionUsername
    $sessionUsername = $_SESSION["username"];
    //uses prepared statement to check if the username exists
    $sql = mysqli_prepare($conn, "SELECT username FROM userDetails WHERE username = ?");
    //binds parameters
    mysqli_stmt_bind_param($sql, 's', $newUsername);
    //executes the prepared statement
    mysqli_stmt_execute($sql);
    //binds the result
    mysqli_stmt_store_result($sql);
    //username does not exist
    if(mysqli_stmt_num_rows($sql) == 0 || $newUsername == $sessionUsername)
    {
        //updates the user details with a prepared statement
        $sql = mysqli_prepare($conn, "UPDATE userDetails SET username = ?, password = ? WHERE username = ?");
        //binds parameters
        mysqli_stmt_bind_param($sql, 'sss', $newUsername, $hash, $sessionUsername);
        //executes the prepared statement
        mysqli_stmt_execute($sql);
        //prepared statement to update the username in the events table
        $sql = mysqli_prepare($conn, "UPDATE events SET username = ? WHERE username = ?");
        //binds parameters
        mysqli_stmt_bind_param($sql, 'ss', $newUsername, $sessionUsername);
        //executes
        mysqli_stmt_execute($sql);
        //sets the session username
        $_SESSION["username"] = $newUsername;
        //sets session message
        $_SESSION["message"] = "Successfully Updated";
        //redirecst to user profile
        header("location: userProfile.php");
    }
    else{
        //sets error message
        $_SESSION["errorMessage"] = "Username Is Taken";
        //redirects to user profile
        header("location: userProfile.php");
    }
}

//input validation
function validate($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>
</body></html>