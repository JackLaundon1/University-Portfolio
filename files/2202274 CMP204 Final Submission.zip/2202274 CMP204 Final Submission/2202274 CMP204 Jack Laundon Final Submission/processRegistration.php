<html><body>
<?php
//starts the session
ob_start();
session_start();
//includes database connection information
include_once("includes/connectionString.php");
//sets variables
$username = $password = "";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $username = validate($_POST["username"]);
    $password = validate($_POST["password"]);
    $confirmPassword = validate($_POST["confirmPassword"]);
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    $confirmPassword = mysqli_real_escape_string($conn, $confirmPassword);    
    $hash = password_hash($password, PASSWORD_DEFAULT);

    //checks if the user already exists in the database using a prepared statement
    $sql = mysqli_prepare($conn, "SELECT username, password FROM userDetails WHERE username = ?");
    //binds username paramater to check if the username exists
    mysqli_stmt_bind_param($sql, 's', $username);
    //executes the prepared statement
    mysqli_stmt_execute($sql);
    //binds the result and stores the username and password into variables
    mysqli_stmt_store_result($sql);
   //username does not exist and the passwords match
   if(mysqli_stmt_num_rows($sql) == 0 && $password == $confirmPassword)
   {
       //starts to create the prepared statement
       $sql = mysqli_prepare($conn, "INSERT INTO userDetails (username, password) VALUES (?,?)");
       //binds parameters
       mysqli_stmt_bind_param($sql, 'ss', $username, $hash);
       //executes the prepared statement
       mysqli_stmt_execute($sql);
       //starts the session
       session_start();
       //sets the session username 
       $_SESSION["username"] = $username;
       //redirects to user profile
       header("location: userProfile.php");
   }
    //username is taken
    else if(mysqli_stmt_num_rows($sql)>0){
        //sets the error message
        $_SESSION["errorMessage"] = "Username is taken";
        //redirects to register.php
        header("location: register.php");
    }
    //if the passwords do not match
    else if($password != $confirmPassword)
    {
        //sets error message
        $_SESSION["errorMessage"] = "Passwords Do Not Match";
        //redirects to register.php
        header("location: register.php");
    }
}

//input validation
function validate($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//closes statement and connection
mysqli_stmt_close($sql);
mysqli_close($conn);

?>
</body></html>