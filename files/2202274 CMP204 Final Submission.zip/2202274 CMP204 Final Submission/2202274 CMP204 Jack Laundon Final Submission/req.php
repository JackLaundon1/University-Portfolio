<!doctype html>

<html lang="en">
<head>
	<meta charset="utf-8">
	<title>CMP204 Unit Two Coursework Template</title>
    <meta name = "viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
	<link rel="stylesheet" href="css/style.css">
	<script src="javascript/script.js"></script>
</head>
<body>
    <header>
        <?php include_once "includes/links.php" ?>
    <headers>
    
    <h1>CMP204 Requirements Page - Unit 2 Assessment</h1>
    
    <p>If you have not met a requirement, do not delete it from the table.</p>

        <table id="reqTable" class = "text-white">
        <thead>
            <tr>
            <th class="reqCol">Requirement</th>
            <th class="metCol">How did you meet this requirement?</th>
            <th class="fileCol">File name(s), line no.</th>
            </tr>
        </thead>

        <tbody>
            <tr>
            <td>HTML5, CSS, JavaScript has been contained within separate files.</td>
            <td>Yes, my HTML, CSS, and JavaScript is in separate files</td>
            <td>every php file, style.css, script.js</td>
            </tr>

            <tr>
            <td>Use of the Bootstrap framework providing a responsive layout.</td>
            <td>I have used bootstrap's grid system throughout the website, through columns and rows, as well as the build in cards feature and buttons</td>
            <td>Index.php lines 32-140, login.php lines 38-72, register.php lines 38-67, teamMembers.php lines 26-116, upcomingEvents.php lines 19-96, userProfile.php lines 54-67  </td>
            </tr>

            <tr>
            <td>Use of JavaScript to manipulate the DOM based on an event.</td>
            <td>Used an event listener to darken and raise the images when the mouse is over them, and when the mouse is not over it, event listeners are added to the logout and delete buttons</td>
            <td>script.js, line 169, 152, 137, 110-132</td>
            </tr>            
            
            <tr>
            <td>Use of jQuery in conjunction with the DOM.</td>
            <td>Jquery was used with the DOM by changing the html of the event form on userProfile.php accordingly depending on which button was clicked, as well as setting the max date attribute on the event form using a function I wrote and using the .attr feature</td>
            <td>script.js, lines 35,42</td>
            </tr>

            <tr>
            <td>Use of AJAX (pure JavaScript i.e. without the use of a library).</td>
            <td>AJAX was used to display information from a database.  When the get player stats button on teamMembers.php is clicked, AJAX is used to get the number of wins, losses, and draws for each player stored in a table in my database.  Note: the information in the database is made up by me, but AJAX is being used to display the information in the database without refreshing the page.  AJAX is also being used to pull information from files to display information about the team members without refreshing the page </td>
            <td>script.js, lines 56-105, 216-228</td>
            </tr>

            <tr>
            <td>Use of the jQuery AJAX function.</td>
            <td>jQuery AJAX function is used to display the events that a user has added from the database. When the loadEvents button is clicked, the jquery ajax method is used to load more events without refreshing the page by interacting with the database and loadData.php</td>
            <td>script.js, lines 27-31  </td>
            </tr>

            <tr>
            <td>User login functionality (PHP/MySQL).</td>
            <td>The user can register and log in through the use of PHP and MYSQL to communicate with a database</td>
            <td>processRegistration.php lines 2-74, processLogin.php lines lines 2-56</td>
            </tr>

            <tr>
            <td>Ability to select (SELECT), add (INSERT), edit (UPDATE) and delete (DELETE) information from a database (PHP/MySQL).</td>
            <td>SELECT is used to log the user in and verify that the user exists, it is also used to display events and verify that events exist before editing or deleting the event.  INSERT is used to register a user and to add an event to the database.  UPDATE is used to update a user's username and password, as well as updating events in the database.  DELETE is used to delete events from the database and delete a user's account, where every field in the users database is deleted for that user and all of their events are also deleted.</td>
            <td>addEventsAttended.php lines 19-47, deleteAccount.php lines 12-22, deleteEventsAttended.php lines 21-38, editEventsAttended.php lines 26-52, getStats.php line 21, loadData.php line 18, processLogin.php lines 18-25, processRegistration.php lines 21-32, processUpdate.php lines 19-36, userProfile.php line 125 </td>
            </tr>

            <tr>
            <td>Inclusion of GDPR.</td>
            <td>A GDPR policy using the provided template and privacy seal is included in the file gdpr.php</td>
            <td>gdpr.php - privacy seal image on line 19, privacy policy on lines 23-51</td>
            </tr>

            <tr>
            <td>SQL queries written as prepared statements.</td>
            <td>All SQL queries are written as prepared statements</td>
            <td>addEventsAttended.php lines 19-34, deleteAccount.php lines 12-22, deleteEventsAttended.php lines 21-36, editEventsAttended.php lines 26-52, getStats.php lines 21-25, loadData.php lines 20-24, processLogin.php lines 18-25, processRegistration.php lines 21-29, processUpdate.php lines 19-40, userProfile.php lines 124-134</td>
            </tr>

            <tr>
            <td>Passwords should be salted and hashed.</td>
            <td>Passwords are salted and hashed using password_hash() and password_verify()</td>
            <td>processLogin.php lines 14,15,27, processRegistration line 18, processUpdate.php line 14</td>
            </tr>

            <tr>
            <td>User input should be sanitised.</td>
            <td>User input is sanitised using trim, stripslashes,htmlspecialchars, and mysqli_real_escape_string</td>
            <td>addEventsAttended.php lines 10-15, 51-57, deleteEventsAttended.php lines 11-16, 54-59, editEventsAttended.php lines 11-22, 77-81, processLogin.php lines 11-14, 45-49, processRegistration.php lines 12-17, 64-67, processUpdate.php lines 10-13, 59-62 </td>
            </tr>
        </tbody>



        </table>

    <!-- jQuery library -->
		<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>

    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>