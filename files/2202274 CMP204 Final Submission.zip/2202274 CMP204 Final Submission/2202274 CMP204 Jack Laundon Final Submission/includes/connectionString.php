<?php

/*
	Desc: Example connection string
	
	Author: Lynsay A. Shepherd
	
	Date: October 2023
	
*/

//connection details
$servername = "lochnagar.abertay.ac.uk";
$dbusername = "sql2202274";
$dbpassword = "couples sisters newport laptop";
$dbname = "sql2202274";

//create connection
$conn = mysqli_connect($servername, $dbusername, $dbpassword, $dbname);

//check connection
if(!$conn)
{
	die("Connection Failed: " .mysqli_connect_error());
}

//mysqli_close($conn);

?>