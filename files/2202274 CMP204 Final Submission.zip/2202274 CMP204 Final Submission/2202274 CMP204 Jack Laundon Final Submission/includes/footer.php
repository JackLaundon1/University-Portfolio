<footer class="text-center text-white">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm">
                <ul>
                    <!--links in footer-->
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="upcomingEvents.php">Upcoming Events</a></li>
                    <li class="nav-item"><a class="nav-link" href="teamMembers.php">Team Members</a></li>
                    <li class="nav-item"><a class="nav-link" href="req.php">Requirements</a></li>
                    <?php 
                        //if the user is signed in 
                        if(!isset($_SESSION["username"]))
                        {
                            echo "<li class = nav-item ><a class = nav-link href=register.php>Register</a></li>";
                            echo "<li class = nav-item><a class = nav-link href=login.php>Login</a></li>";
                        }
                        //if the user is signed in
                        else if(isset($_SESSION["username"]))
                        {
                            echo "<li class = nav-item><a class = nav-link href=userProfile.php>User Profile</a></li>";
                            echo "<li class = nav-item><a class = nav-link id = logoutFooter href=logout.php>Logout</a></li>";
                        }
                    ?>
                </ul>
            </div>
        </div>
        <hr class="hr">
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm">
                <div class="copyright">
                    <p>Copyright CMP204 2023</p>
                </div>
            </div>
        </div>
    </div>
</footer>