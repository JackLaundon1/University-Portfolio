        <?php
        ob_start();
        session_start();
        ?>
        <nav class = "navbar navbar-expand-sm navbar-dark" >
            <div class = "container-fluid">
                    <ul class = "navbar-nav">
                        <button class = "navbar-toggler" type = "btn btn-outline-light" data-bs-toggle="collapse" data-bs-target = "#collapsibleNavbar">
                            <span class = "navbar-toggler-icon"></span>
                        </button>
                        <div class = "collapse navbar-collapse" id = "collapsibleNavbar">
                            <!--Image of esports logo used from https://images-platform.99static.com//L-05gq1xZY1qMiWb1YbCl0bmKpI=/107x65:891x849/fit-in/500x500/99designs-contests-attachments/111/111797/attachment_111797391-->
                            <a class="navbar-brand" href="index.php"><img src="images\logo.jfif" height = 100px width = 100px alt="Esports logo" class = "rounded"></a>
                            <li class = "nav-item"><a class = "nav-link" href="index.php">Home</a></li>
                            <li class = "nav-item"><a class = "nav-link" href="upcomingEvents.php">Upcoming Events</a></li>
                            <li class = "nav-item"><a class = "nav-link" href="teamMembers.php">Team Members</a></li>
                            <li class = "nav-item"><a class = "nav-link" href="req.php">Requirements</a></li>
        <!--only show if user is not signed in-->
                            <?php 
                            if(!isset($_SESSION["username"]))
                            {
                                echo "<li class = nav-item ><a class = nav-link href=register.php>Register</a></li>";
                                echo "<li class = nav-item><a class = nav-link href=login.php>Login</a></li>";
                            }
                            ?>
        <!--only show if authenticated user is signed in-->
                            <?php 
                            if(isset($_SESSION["username"]))
                            {
                                echo "<li class = nav-item><a class = nav-link href=userProfile.php>User Profile</a></li>";
                                echo "<li class = nav-item><a class = logout nav-link id = logoutlink href=logout.php>Logout</a></li>";
                            }
                            ?>
                        </div>
                    </ul> 
            </div>
        </nav>