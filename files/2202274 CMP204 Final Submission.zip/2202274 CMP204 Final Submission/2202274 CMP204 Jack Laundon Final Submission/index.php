<!doctype html>

<html lang="en">
<head>
    <!--sets up the web page-->
	<meta charset="utf-8">
	<title>COOL ESPORTS TEAM</title>
    <meta name = "viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
	<link rel="stylesheet" href="css/style.css">
	<script src="javascript/script.js"></script>
    <!-- jQuery library -->
	<script src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
</head>
<body>
    <header>
        <!-- includes the navbar -->
        <?php include_once "includes/links.php" ?>
        <div class = "jumbotron">
            <!-- jumbotron -->
            <div class = "p-5 text-center bg-image">
                    <div class="d-flex justify-content-center align-items-center h-100">
                        <div class="text-white">
                            <h1 class="mb-3">Do The Impossible</h1>
                            <h4 class="mb-3">Be Unbeatable</h4>
                            <a class="btn btn-outline-light btn-lg" href="login.php" role="button">Sign In</a>
                        </div>
                    </div>
            </div>
        </div>
    </header>
    <div class = "container">
        <div class = "row">
            <div class = "col-sm">
                <div class = "subheading">
                    <p class = "text-center display-4 lead"><strong>Lorem, ipsum dolor sit amet consectetur</p>
                </div>
            </div>
        </div>
    </div>
    <div class = "container-fluid">
        <div class = "dummy-text">
            <div class = "row justify-content-sm-center">
                <!-- text columns -->
                <div class = "col-sm text-center">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veniam minus asperiores perspiciatis non, odit a magni eos totam corrupti distinctio? Aliquid atque voluptatibus rem architecto totam est omnis error illum.</p>
                </div>
                <div class = "col-sm text-center">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veniam minus asperiores perspiciatis non, odit a magni eos totam corrupti distinctio? Aliquid atque voluptatibus rem architecto totam est omnis error illum.</p>
                </div>
                <div class = "col-sm text-center">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veniam minus asperiores perspiciatis non, odit a magni eos totam corrupti distinctio? Aliquid atque voluptatibus rem architecto totam est omnis error illum.</p>
                </div>
                <div class = "col-sm text-center">
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Veniam minus asperiores perspiciatis non, odit a magni eos totam corrupti distinctio? Aliquid atque voluptatibus rem architecto totam est omnis error illum.</p>
                </div>
            </div>
        </div>
    </div>

    <div class = "team heading">
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-sm">
                    <div class = "p-5 text-center bg-image">
                        <h2>The Team</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class = "container-fluid">
        <div class = "cards">
            <!-- cards -->
            <div class = "row">
                <div class = "col-sm-3">
                    <div class="card text-center mx-auto border-dark mb-3">
                    <!-- image from https://static.gosugamers.net/d8/9d/84/6356d0f38547d67cdc63e240d32661d5d705374f9d59fe928c83012e07.png -->
                        <img class="card-img-top" src="images\player1.webp" alt="Card image">
                        <div class="card-body">
                            <h5 class="card-title">Puppey</h5>
                            <!-- Information from: https://liquipedia.net/dota2/Puppey-->
                                <p class="card-text">Clement "Puppey" Ivanov is an Estonian eSports player most recently known for playing for the eSports team "Team Secret"</p>
                            <a href="teamMembers.php" class="btn btn-primary">Find out More!</a>
                        </div>
                    </div>
                </div>
                <div class = "col-sm-3">
                    <div class="card text-center mx-auto border-dark mb-3">
                    <!-- image from https://prosettings.net/wp-content/uploads/jjonak.png -->
                        <img class="card-img-top" src="images\player2.webp" alt="Card image">
                        <div class="card-body">
                            <h5 class="card-title">JJonak</h5>
                            <!-- Information from: https://liquipedia.net/overwatch/JJoNak -->
                            <p class="card-text">Sung-hyeon "JJonak" Bang is a South Korean eSports player, most recently known for playing for the eSports team "Seoul Dynasty"</p>
                            <a href="teamMembers.php" class="btn btn-primary">Find out More!</a>
                        </div>
                    </div>
                </div>
                <div class = "col-sm-3">
                    <div class="card text-center mx-auto border-dark mb-3" >
                    <!--image from https://static.wikia.nocookie.net/halo_esports_gamepedia_en/images/2/26/Peatie_Minnesota_2020.png/revision/latest?cb=20220119212400_ -->
                        <img class="card-img-top" src="images\player3.webp" alt="Card image">
                        <div class="card-body">
                            <h5 class="card-title">Peatie</h5>
                            <!-- Information from: https://cod-esports.fandom.com/wiki/Peatie -->
                            <p class="card-text">Adam "Peatie" Peate is an English eSports player, most recently known for playing for the eSports team "Noctem Black"</p>
                            <a href="teamMembers.php" class="btn btn-primary">Find out More!</a>
                        </div>
                    </div>
                </div>
                <div class = "col-sm-3">
                    <div class="card text-center mx-auto border-dark mb-3">
                    <!--image from https://static.gosugamers.net/57/f6/ca/f6b0e5f1891b03f7f0a51fcd83e6d94405fe266c80ba8eefba20566efb.png -->
                        <img class="card-img-top" src="images\player4.webp" alt="Card image">
                        <div class="card-body">
                            <h5 class="card-title">Faker</h5>
                            <!-- Information from: https://liquipedia.net/leagueoflegends/Faker -->
                            <p class="card-text">Lee "Faker" Sang-hyeok is a South Korean eSports, most recently known for playing for the eSports team "T1"</p>
                            <a href="teamMembers.php" class="btn btn-primary">Find out More!</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <?php include_once "includes/footer.php" ?>
    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>
</html>