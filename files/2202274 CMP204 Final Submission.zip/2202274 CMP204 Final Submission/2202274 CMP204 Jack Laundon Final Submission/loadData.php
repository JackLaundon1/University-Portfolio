<?php 
    ob_start();
    session_start();
    include_once("includes/connectionString.php");
    $sessionUsername = $_SESSION["username"];
    $updatedEventNum = $_POST["updatedEventNum"];
    $numShown = 4;
    $balance = ($updatedEventNum - 4);

    $name = "";
    $date = "";
    $location = "";


    //sql prepared statement to display the next four events on the page, using limits and the SQL ORDER BY function
    $sql = mysqli_prepare($conn, "SELECT eventname, eventDate, eventLocation FROM events WHERE username = ? ORDER BY eventDate DESC LIMIT ?, ?");
    //binds parameters
    mysqli_stmt_bind_param($sql, 'sii', $sessionUsername, $balance, $numShown);
    //executes the prepared statement
    mysqli_execute($sql);
    //binds the result
    mysqli_stmt_bind_result($sql, $name, $date, $location);
    //outputs the results
    echo "<div class = 'row'>";
    while(mysqli_stmt_fetch($sql))
    {
        echo    "<div class = 'col-sm'>
        <div class='card bg-dark text-white text-center mx-auto border-dark mb-3'>
            <div class='card-body text-center'>
                <h5 class='card-title text-center'>{$name}</h5>
                <p class='card-text text-center'>{$date} <br> {$location}</p>
                <a href='#formEvent' class='btn btn-light edit'>Edit This Event</a>
                <a href='#formEvent' class='btn btn-light delete'>Delete This Event</a>
            </div>
        </div>
    </div> ";         
    }
    echo "</div> <hr>";
    //closes the statement
    mysqli_stmt_close($sql);
    mysqli_close($conn);
?>