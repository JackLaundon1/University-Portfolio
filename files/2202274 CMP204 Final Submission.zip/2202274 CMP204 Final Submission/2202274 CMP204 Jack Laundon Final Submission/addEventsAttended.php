<html><body>
<?php
include_once("includes/connectionString.php");
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    //starts the session
    ob_start();
    session_start();
    //sets variables
    $eventName = validate($_POST["eventName"]);
    $eventDate = validate($_POST["eventDate"]);
    $eventLocation = validate($_POST["eventLocation"]);
    $eventName = mysqli_real_escape_string($conn, $eventName);
    $eventDate = mysqli_real_escape_string($conn, $eventDate);
    $eventLocation = mysqli_real_escape_string($conn, $eventLocation);
    $sessionUsername = $_SESSION["username"];

    //checks if the user already exists in the database using a prepared statement
    $sql = mysqli_prepare($conn, "SELECT eventname FROM events WHERE eventname = ? AND eventDate = ? AND eventLocation = ? AND username = ?");
    //binds parameters
    mysqli_stmt_bind_param($sql, 'ssss', $eventName, $eventDate, $eventLocation, $sessionUsername);
    //executes the prepared statement
    mysqli_stmt_execute($sql);
    //binds the result
    mysqli_stmt_store_result($sql);
    //event does not exist
    if(mysqli_stmt_num_rows($sql) == 0)
    {
        //starts to create the prepared statement
        $sql = mysqli_prepare($conn, "INSERT INTO events (eventname, eventDate, eventLocation, username) VALUES (?,?,?,?)");
        //binds parameters
        mysqli_stmt_bind_param($sql, 'ssss', $eventName, $eventDate, $eventLocation, $sessionUsername);
        //executes the prepared statement
        mysqli_stmt_execute($sql);
        //sets the session message
        $_SESSION["message"] = "Event Added Successfully";
        //redirects to user profile
        header("location: userProfile.php");
    }
    //event exists
    else{
        //sets session message
        $_SESSION["errorMessage"] = "Event Already Exists";
        //redirects to user profile
        header("location: userProfile.php");
    }        
}


//input validation
function validate($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
 ?>
</body></html>