<?php 
    ob_start();
    session_start();
    //if the user is not logged in, redirect to index.php
    if(!isset($_SESSION['username']))
    {
        header("location:index.php");
    }    
    ?>

<!doctype html>

<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CMP204 Unit Two Coursework Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <!-- jQuery library -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script src="javascript/script.js"></script>
</head>

<body>
    <header>
        <?php include_once "includes/links.php" ?>
    </header>

    <h2 class="text-center">Welcome back,
        <!-- displays username -->
        <?php echo $_SESSION["username"];?>
    </h2>
    <hr>
    <?php
    //if session messages are set, display them
                if(isset($_SESSION["errorMessage"]))
                {
                    echo "<h3 class = 'text-danger text-center'>Error: {$_SESSION['errorMessage']}</h3>";
                    unset($_SESSION["errorMessage"]);
                }
                if(isset($_SESSION["message"]))
                {
                    echo "<h3 class = 'text-success text-center'>{$_SESSION['message']}</h3>";
                    unset($_SESSION["message"]);
                }
                echo "<hr>";
                ?>
    <h3 class="text-center text-white">Update Your Details</h3>
    <br>
    <div class="container text-center">
        <div class="row">
            <div class="col-sm mx-auto text-white">
                <!-- form -->
                <form action="processUpdate.php" class="form" method="post">
                    New Username: <input type="text" name="username" required> <br>
                    New Password: <input type="password" minlength="8" name="password" required> <br>
                    <br>
                    <div class="text-center text-white">
                        <button type="submit" class="btn btn-dark">Submit</button>
                    </div>
                    <br>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-sm mx-auto text-white" id = "formEvent">
                <h3 class="text-center text-white" id="formh3">Add Event</h3>
                <form action="addEventsAttended.php" class="form" id="eventForm" method="post">
                    <div id="formInputs">
                        <!-- form -->
                        Event Name: <input type="text" name="eventName" required> <br>
                        Event Date: <input type="date" id="dateInput" name="eventDate" required> <br>
                        Event Location: <input type="text" name="eventLocation" required> <br>
                    </div>
                    <br>
                    <div class="text-center text-white">
                        <button type="submit" class="btn btn-dark" id="submitEventButton">Submit</button>
                    </div>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <div class="container-fluid text-center">
        <div class="row">
            <div class="col-sm">
                <hr>
                <h2 class="text-center">Your Events</h2>
                <br>
            </div>
        </div>
        <!-- display events -->
        <div class="row">
            <div class="col-sm-4 text-center">
                <button id="addEventButton" type="submit" class="btn btn-dark">Add Event</button>
            </div>
            <div class="col-sm-4 text-center">
                <button id="editEventButton" type="submit" class="btn btn-dark">Edit Existing Event</button>
            </div>
            <div class="col-sm-4 text-center">
                <button id="deleteEventButton" type="submit" class="btn btn-dark">Delete Event</button>
            </div>
            <div>
            <hr>
        </div>
        <br>
        <div class = "text-center" id="eventOutput"></div>
        <?php 
        //starts the session
                        ob_start();
                        session_start();
                        include_once("includes/connectionString.php");
                        //sets variables
                        $sessionUsername = $_SESSION["username"];
                        $limit = 4;
                        $name = "";
                        $date = "";
                        $location = "";

                        //sql query to select event details but limits the number display to four, using limits and  using the SQL ORDER BY function
                        $sql = mysqli_prepare($conn, "SELECT eventname, eventDate, eventLocation FROM events WHERE username = ? ORDER BY eventDate DESC LIMIT ?");
                        //binds parameters
                        mysqli_stmt_bind_param($sql, 'si', $sessionUsername, $limit);
                        //executes the prepared statement
                        mysqli_execute($sql);
                        //binds the results
                        mysqli_stmt_bind_result($sql, $name, $date, $location);
                        //outputs the results
                        echo "<div class = 'row'>";
                        while(mysqli_stmt_fetch($sql))
                        {                           
                            echo    "<div class = 'col-sm'>
                                            <div class='card bg-dark text-white text-center mx-auto border-dark mb-3'>
                                                <div class='card-body text-center'>
                                                    <h5 class='card-title text-center'>{$name}</h5>
                                                    <p class='card-text text-center'>{$date} <br> {$location}</p>
                                                    <a href='#formEvent' class='btn btn-light edit'>Edit This Event</a>
                                                    <a href='#formEvent' class='btn btn-light delete'>Delete This Event</a>
                                                </div>
                                            </div>
                                    </div> ";     
                        }
                        echo "</div> <hr>";
                        //closes the statement
                        mysqli_stmt_close($sql);
                        mysqli_close($conn);
        ?>
    </div>
    <div class="row">
        <div class="col-sm text-center">
            <hr>
            <button type="submit" class="btn btn-dark" id="loadEventsButton">Load More Events</button>
            <hr>
        </div>
    </div>
    </div>
    <div class="container text-center text-white">
        <div class="row">
            <div class="col-sm">
                <button type="button" class="btn btn-danger" id="deleteButton">Delete Account</button>
            </div>
        </div>
    </div>
    <br>
    <?php include_once "includes/footer.php" ?>
    <!-- Latest compiled Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>

</html>