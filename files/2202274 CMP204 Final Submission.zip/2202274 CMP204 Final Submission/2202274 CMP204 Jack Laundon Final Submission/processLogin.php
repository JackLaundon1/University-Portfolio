<html><body>
<?php
//starts the session
ob_start();
session_start();
include_once("includes/connectionString.php");
//sets variables
$username = $password = "";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    $username = validate($_POST["username"]);
    $password = validate($_POST["password"]);
    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);
    $hash = password_hash($password, PASSWORD_DEFAULT);

    //checks if the user already exists in the database using a prepared statement
    $sql = mysqli_prepare($conn, "SELECT username, password FROM userDetails WHERE username = ?");
    //binds username paramater to check if the username exists
    mysqli_stmt_bind_param($sql, 's', $username);
    //executes the prepared statement
    mysqli_stmt_execute($sql);
    //binds the result and stores the username and password into variables
    mysqli_stmt_bind_result($sql, $fetchedUsername, $hashedPassword);
    mysqli_stmt_fetch($sql);
    //checks to see if the user details are correct
    if($username == $fetchedUsername && password_verify($password, $hashedPassword))
    {
        //sets session username
        $_SESSION["username"] = $username;
        //redirects to user profile
        header("location: userProfile.php");
    }
    //user does not exist
    else{
        //sets error message
        $_SESSION["errorMessage"] = "User Not Found";
        //redirects to login
        header("location: login.php");
    }
}

//input validation
function validate($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

//closes the statement and connection
mysqli_stmt_close($sql);
mysqli_close($conn);

?>
</body></html>