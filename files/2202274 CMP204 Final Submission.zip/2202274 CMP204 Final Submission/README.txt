The login details are:
Username - test
Password - testing123

I have already added eight events that the user would have attended to the database